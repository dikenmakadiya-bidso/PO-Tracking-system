declare module '*.md?raw' {
  const content: string;
  export default content;
}

export interface POData {
  id: string;
  date: string;
  rmCode: string;
  rmName: string;
  quantity: number;
  price: number;
  plantName: string;
  amount: number;
  vendor: string;
  specialRemark: string;
  systemPOGenerated: boolean;
  bidsoPONo: string;
  receivedQty: number;
  expectedDeliveryDate: string;
  invUom?: string;
  conversionFactor?: number;
}

export interface InwardLog {
  id: string; // Internal ID for React keys
  poId: string; // Bidso PO No
  date: string; // Entry Date
  newReceivedQuantity: number;
  timestamp: number;
  rmCode: string;
  rmName: string;
  plantName: string;
  entryNote: string;
}

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { ErrorBoundary } from './components/ErrorBoundary';
import { FeatureProvider, useFeatures } from './context/FeatureContext';
import { CONFIG } from './config';
import { 
  LayoutDashboard, 
  PlusCircle, 
  Search, 
  Filter, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle,
  Package,
  Factory,
  FileText,
  Calendar,
  User,
  ChevronRight,
  Database,
  ArrowLeft,
  IndianRupee,
  MessageSquare,
  Truck,
  Tag,
  Weight,
  List,
  RefreshCw,
  Info,
  Clock,
  BarChart3,
  LogOut,
  Lock,
  ShieldAlert,
  ShieldCheck,
  Loader2,
  Cloud,
  CloudOff,
  Trash2,
  ChevronDown
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  LineChart,
  Line,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { POData, InwardLog } from './types';
import { ApiService } from './services/api';
import { Header, TabBar } from './components/Layout';
import { AppMenu } from './components/AppMenu';
import { Card, Badge, DateDisplay, parseDate, formatDate, isDatePassed } from './components/Common';

interface User {
  email: string;
  name?: string;
  picture?: string;
}

// --- Main App ---

export default function App() {
  return (
    <ErrorBoundary>
      <FeatureProvider>
        <AppContent />
      </FeatureProvider>
    </ErrorBoundary>
  );
}

function AppContent() {
  const { getFeature } = useFeatures();
  const [activeTab, setActiveTab] = useState<'history' | 'inward' | 'logs' | 'analysis'>('history');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [selectedYear, setSelectedYear] = useState<string>('All');
  const [selectedAnalysisPlant, setSelectedAnalysisPlant] = useState<string>('All');
  const [pos, setPos] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('local_pos');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });
  const [logs, setLogs] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('local_fetched_logs');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });
  
  // Auth State
  const [user, setUser] = useState<User | null>(null);
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [isCheckingAuth, setIsCheckingAuth] = useState(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [tokens, setTokens] = useState<any>(() => {
    try {
      const saved = localStorage.getItem('google_tokens');
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });
  
  // Initialize localLogs from localStorage for persistence
  const [localLogs, setLocalLogs] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('local_inward_logs');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  const [poHeaders, setPoHeaders] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('local_po_headers');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });
  const [logHeaders, setLogHeaders] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('local_log_headers');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });
  const [idHeader, setIdHeader] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('local_id_header');
      return saved || 'Unique ID';
    } catch (e) {
      return 'Unique ID';
    }
  });
  
  const [pendingMasterUpdates, setPendingMasterUpdates] = useState<any[]>(() => {
    try {
      const saved = localStorage.getItem('local_pending_master_updates');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });
  
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  
  const [isSyncing, setIsSyncing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showDebug, setShowDebug] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [selectedHistoryPO, setSelectedHistoryPO] = useState<any>(null);

  // Persist lists and headers to localStorage for offline persistence
  React.useEffect(() => {
    localStorage.setItem('local_pos', JSON.stringify(pos));
  }, [pos]);

  React.useEffect(() => {
    localStorage.setItem('local_fetched_logs', JSON.stringify(logs));
  }, [logs]);

  React.useEffect(() => {
    localStorage.setItem('local_po_headers', JSON.stringify(poHeaders));
    localStorage.setItem('local_log_headers', JSON.stringify(logHeaders));
    localStorage.setItem('local_id_header', idHeader);
  }, [poHeaders, logHeaders, idHeader]);

  React.useEffect(() => {
    localStorage.setItem('local_pending_master_updates', JSON.stringify(pendingMasterUpdates));
  }, [pendingMasterUpdates]);

  React.useEffect(() => {
    localStorage.setItem('local_inward_logs', JSON.stringify(localLogs));
  }, [localLogs]);

  // Online/Offline listener
  React.useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      if (user && tokens) {
        syncAll();
      }
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [user, tokens]);

  // Cleanup old logs on mount (older than 24h)
  React.useEffect(() => {
    const twentyFourHoursAgo = Date.now() - 24 * 60 * 60 * 1000;
    setLocalLogs(prev => prev.filter(log => !log._createdAt || log._createdAt > twentyFourHoursAgo));
  }, []);

  // Pre-warm connection for Inward operations to prevent cold-start JSON errors
  React.useEffect(() => {
    if (activeTab === 'inward' && user && tokens) {
      ApiService.checkAuth(tokens).catch(() => {});
    }
  }, [activeTab, !!user, !!tokens]);

  // Auth Effects
  React.useEffect(() => {
    checkAuth();
    
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        if (event.data.tokens) {
          // Merge tokens to avoid losing the refresh token
          setTokens((prev: any) => {
            const merged = { ...(prev || {}), ...event.data.tokens };
            localStorage.setItem('google_tokens', JSON.stringify(merged));
            return merged;
          });
          if (event.data.user) setUser(event.data.user);
          setTimeout(() => checkAuth(event.data.tokens), 100);
        } else {
          // Fallback to session check
          setTimeout(checkAuth, 500);
        }
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const checkAuth = async (currentTokens?: any) => {
    const timeout = setTimeout(() => {
      setIsCheckingAuth(false);
      setAuthError('Session verification taking longer than expected...');
    }, 8000);

    try {
      setIsCheckingAuth(true);
      const activeTokens = currentTokens || tokens;
      const { data, error } = await ApiService.checkAuth(activeTokens);
      
      if (data) {
        if (data.user) setUser(data.user);
        setHasPermission(data.hasPermission);
        setAuthError(null);
        
        if (data.hasPermission) {
          syncAll(activeTokens);
        }
      } else {
        setUser(null);
        setHasPermission(null);
        
        if (activeTokens && error && error !== 'Not authenticated') {
          console.warn('Auth failed with tokens, clearing local storage:', error);
          localStorage.removeItem('google_tokens');
          setTokens(null);
        }
      }
    } catch (err: any) {
      console.error('Auth check error:', err);
      setAuthError(err.message || 'Verification failed');
    } finally {
      clearTimeout(timeout);
      setIsCheckingAuth(false);
    }
  };

  const handleLogin = async () => {
    const { data, error } = await ApiService.getAuthUrl();
    if (data?.url) {
      window.open(data.url, 'google_oauth', 'width=600,height=700');
    } else {
      console.error('Login failed:', error);
    }
  };

  const handleLogout = async () => {
    await ApiService.logout(tokens);
    setUser(null);
    setHasPermission(null);
    setTokens(null);
    localStorage.removeItem('google_tokens');
    setPos([]);
    setLogs([]);
  };

  const onGestureSwipe = (_event: any, info: any) => {
    // Feature Flag: Only process swipes if the feature is enabled
    // We use getFeature() from context to allow live overrides in development
    if (!getFeature('enableBetaGestures')) return;
    
    if (window.innerWidth >= 1024) return;
    // Disable swipe if an overlay modal is active
    if (selectedHistoryPO || showResetConfirm) return;

    const { offset, velocity } = info;
    const SWIPE_THRESHOLD = 40; 
    const VELOCITY_THRESHOLD = 500;
    
    // Check if movement is primarily horizontal (at least 1.5x more than vertical)
    const isHorizontal = Math.abs(offset.x) > Math.abs(offset.y) * 1.5;
    
    if (isHorizontal) {
      // Trigger on significant distance OR high velocity flick
      if (Math.abs(offset.x) > SWIPE_THRESHOLD || Math.abs(velocity.x) > VELOCITY_THRESHOLD) {
        if (offset.x > 0) handleSwipe('right');
        else handleSwipe('left');
      }
    }
  };

  const handleReset = () => {
    setShowResetConfirm(true);
  };

  const confirmReset = () => {
    localStorage.clear();
    setLocalLogs([]);
    handleLogout();
    setShowResetConfirm(false);
    // Instead of reload, we just let state updates handle it
    // But a reload is cleaner for a full reset if possible
    window.location.reload();
  };

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [logSearchQuery, setLogSearchQuery] = useState('');
  
  // Inward Workflow State
  const [workflowStep, setWorkflowStep] = useState(1);
  const [selectedPlant, setSelectedPlant] = useState('');
  const [selectedBidsoPO, setSelectedBidsoPO] = useState('');
  const [poSearchQuery, setPoSearchQuery] = useState('');
  const [selectedRMCode, setSelectedRMCode] = useState('');
  const [invUom, setInvUom] = useState('');
  const [conversionFactor, setConversionFactor] = useState('');
  const [newQty, setNewQty] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  // --- Consolidated Logs and Enriched POs ---

  const allLogs = useMemo(() => {
    // Combine fetched logs and local logs, removing duplicates based on timestamp
    const consolidated = [...localLogs];
    
    logs.forEach(fetchedLog => {
      const isDuplicate = localLogs.some(local => 
        String(local['Time stamp']) === String(fetchedLog['Time stamp']) &&
        String(local['Bidso PO No']) === String(fetchedLog['Bidso PO No']) &&
        String(local['RM Code']) === String(fetchedLog['RM Code'])
      );
      if (!isDuplicate) {
        consolidated.push(fetchedLog);
      }
    });

    // Sort by entry date descending
    return consolidated.sort((a, b) => {
      const dateA = new Date(a['Entry Date'] || a['Time stamp'] || 0).getTime();
      const dateB = new Date(b['Entry Date'] || b['Time stamp'] || 0).getTime();
      return dateB - dateA;
    });
  }, [logs, localLogs]);

  const enrichedPOs = useMemo(() => {
    return pos.map(po => {
      const uniqueId = String(po[idHeader] || '').trim();
      const poId = uniqueId.toLowerCase();
      const rmCode = String(po['RM Code'] || '').trim().toLowerCase();

      // Look if there is a pending master update for this PO
      const pendingUpdate = pendingMasterUpdates.find(u => String(u.uniqueId || '').trim() === uniqueId);
      
      let baseInvUom = po['Inv UOM'];
      let baseFactor = po['Conversion Factor (PCs/KG)'];

      if (pendingUpdate) {
        baseInvUom = pendingUpdate.invUom;
        baseFactor = pendingUpdate.conversionFactor;
      }

      // Find all logs that match this PO
      const poLogs = allLogs.filter(log => {
        const logPoId = String(log[idHeader] || log['Bidso PO No'] || log['Bidso PO no'] || '').trim().toLowerCase();
        const logRmCode = String(log['RM Code'] || '').trim().toLowerCase();
        
        if (idHeader.toLowerCase().includes('unique') && logPoId === poId) return true;
        return logPoId === poId && logRmCode === rmCode;
      });
      
      const logsSum = poLogs.reduce((sum, log) => sum + (Number(log['New Received Quantity']) || 0), 0);
      const baseReceived = Number(po['Received QTY']) || 0;
      const orderQty = Number(po['Order Quantity']) || 0;
      
      const liveReceived = Math.max(baseReceived, logsSum);
      const liveDiff = orderQty - liveReceived;
      
      return {
        ...po,
        'Inv UOM': baseInvUom,
        'Conversion Factor (PCs/KG)': baseFactor,
        'Received QTY': liveReceived,
        'Diff': liveDiff,
        '_debug': {
          base: baseReceived,
          logs: logsSum
        }
      };
    });
  }, [pos, allLogs, idHeader, pendingMasterUpdates]);

  const poLogs = useMemo(() => {
    if (!selectedHistoryPO) return [];
    const poId = String(selectedHistoryPO[idHeader] || '').trim().toLowerCase();
    const rmCode = String(selectedHistoryPO['RM Code'] || '').trim().toLowerCase();
    
    return allLogs.filter(log => {
      const logPoId = String(log[idHeader] || log['Bidso PO No'] || log['Bidso PO no'] || '').trim().toLowerCase();
      const logRmCode = String(log['RM Code'] || '').trim().toLowerCase();
      
      if (idHeader.toLowerCase().includes('unique') && logPoId === poId) return true;
      return logPoId === poId && logRmCode === rmCode;
    });
  }, [selectedHistoryPO, allLogs, idHeader]);

  const filteredPOs = useMemo(() => {
    return enrichedPOs.filter(po => 
      String(po[idHeader] || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      String(po['RM Code'] || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      String(po['Vendor'] || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      String(po['Bidso PO no'] || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      String(po['RM Name'] || '').toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [enrichedPOs, searchQuery]);

  const filteredLogs = useMemo(() => {
    const allLogs = [
      ...localLogs.map(l => ({ ...l, _isLocal: true })),
      ...logs.map(l => ({ ...l, _isLocal: false }))
    ];
    if (!logSearchQuery) return allLogs;
    const query = logSearchQuery.toLowerCase();
    return allLogs.filter(log => 
      String(log['Bidso PO No'] || '').toLowerCase().includes(query) ||
      String(log['RM Code'] || '').toLowerCase().includes(query) ||
      String(log['RM Name'] || '').toLowerCase().includes(query) ||
      String(log['Plant Name'] || '').toLowerCase().includes(query) ||
      String(log['Entry Date'] || '').toLowerCase().includes(query) ||
      String(log['User ID'] || '').toLowerCase().includes(query)
    );
  }, [logs, localLogs, logSearchQuery]);

  const plants = useMemo(() => Array.from(new Set(enrichedPOs.map(p => p['Plant Name']).filter(Boolean))), [enrichedPOs]);
  
  const availableBidsoPOs = useMemo(() => {
    if (!selectedPlant) return [];
    return Array.from(new Set(enrichedPOs.filter(p => p['Plant Name'] === selectedPlant).map(p => p['Bidso PO no']).filter(Boolean)));
  }, [enrichedPOs, selectedPlant]);

  const availableRMCodes = useMemo(() => {
    if (!selectedPlant || !selectedBidsoPO) return [];
    return enrichedPOs.filter(p => p['Plant Name'] === selectedPlant && p['Bidso PO no'] === selectedBidsoPO);
  }, [enrichedPOs, selectedPlant, selectedBidsoPO]);

  const currentPO = useMemo(() => {
    return enrichedPOs.find(p => p['Plant Name'] === selectedPlant && (p[idHeader] === selectedBidsoPO || p['Bidso PO no'] === selectedBidsoPO) && p['RM Code'] === selectedRMCode);
  }, [enrichedPOs, selectedPlant, selectedBidsoPO, selectedRMCode]);

  // Auto-fill UOM and Conversion Factor when currentPO changes
  React.useEffect(() => {
    if (currentPO) {
      const rm = String(currentPO['RM Code'] || '').trim();
      const vendor = String(currentPO['Vendor'] || '').trim();
      
      // Look for any PO with same RM and Vendor that has UOM info
      const match = enrichedPOs.find(p => 
        String(p['RM Code'] || '').trim() === rm && 
        String(p['Vendor'] || '').trim() === vendor && 
        p['Inv UOM'] && 
        p['Conversion Factor (PCs/KG)']
      );

      if (match) {
        setInvUom(String(match['Inv UOM']));
        setConversionFactor(String(match['Conversion Factor (PCs/KG)']));
      } else {
        // Fallback to current PO's own values if present but not found in other matches
        setInvUom(String(currentPO['Inv UOM'] || ''));
        setConversionFactor(String(currentPO['Conversion Factor (PCs/KG)'] || ''));
      }
    }
  }, [currentPO, enrichedPOs]);

  const analysisData = useMemo(() => {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];

    const filteredByYearAndPlant = enrichedPOs.filter(po => {
      const matchesYear = selectedYear === 'All' || String(po['Date'] || '').includes(selectedYear);
      const matchesPlant = selectedAnalysisPlant === 'All' || po['Plant Name'] === selectedAnalysisPlant;
      return matchesYear && matchesPlant;
    });

    const data = months.map(month => ({
      name: month,
      Pending: 0,
      Partial: 0,
      Completed: 0,
      RunningDelay: 0
    }));

    filteredByYearAndPlant.forEach(po => {
      const dateStr = String(po['Date'] || '');
      const date = parseDate(dateStr);
      
      if (date) {
        const monthIdx = date.getMonth();
        const received = Number(po['Received QTY']) || 0;
        const order = Number(po['Order Quantity']) || 0;
        
        let status: 'Pending' | 'Partial' | 'Completed' = 'Pending';
        if (received >= order && order > 0) status = 'Completed';
        else if (received > 0) status = 'Partial';
        
        data[monthIdx][status]++;

        // Running Delay Logic: Not completed and Exp Date passed
        if (status !== 'Completed' && isDatePassed(String(po['Expected delivery date'] || ''))) {
          data[monthIdx].RunningDelay++;
        }
      }
    });

    return data;
  }, [enrichedPOs, selectedYear, selectedAnalysisPlant]);

  const quantityTrendData = useMemo(() => {
    const months = [
      'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
    ];

    const data = months.map(month => ({
      name: month,
      Ordered: 0,
      Received: 0
    }));

    // Aggregate Ordered Quantity (from POs issued in that month)
    enrichedPOs.forEach(po => {
      const dateStr = String(po['Date'] || '');
      const date = parseDate(dateStr);
      
      const matchesYear = selectedYear === 'All' || (date && String(date.getFullYear()) === selectedYear);
      const matchesPlant = selectedAnalysisPlant === 'All' || po['Plant Name'] === selectedAnalysisPlant;

      if (date && matchesYear && matchesPlant) {
        const monthIdx = date.getMonth();
        data[monthIdx].Ordered += (Number(po['Order Quantity']) || 0);
      }
    });

    // Aggregate Received Quantity (from Logs recorded in that month)
    const allLogsForTrend = [...logs, ...localLogs];
    allLogsForTrend.forEach(log => {
      const dateStr = String(log['Entry Date'] || '');
      const date = parseDate(dateStr);
      
      const matchesYear = selectedYear === 'All' || (date && String(date.getFullYear()) === selectedYear);
      const matchesPlant = selectedAnalysisPlant === 'All' || log['Plant Name'] === selectedAnalysisPlant;

      if (date && matchesYear && matchesPlant) {
        const monthIdx = date.getMonth();
        data[monthIdx].Received += (Number(log['New Received Quantity']) || 0);
      }
    });

    return data;
  }, [enrichedPOs, logs, localLogs, selectedYear, selectedAnalysisPlant]);

  const leadTimeAnalysis = useMemo(() => {
    // We'll store stats for (RM + Vendor) and also just (RM) as a fallback
    const rmVendorStats: Record<string, { totalDays: number; count: number; minDays: number; maxDays: number }> = {};
    const rmStats: Record<string, { totalDays: number; count: number; minDays: number; maxDays: number }> = {};
    
    const allLogs = [...localLogs, ...logs];

    enrichedPOs.forEach(po => {
      const rmName = String(po['RM Name'] || 'Unknown').trim();
      const vendor = String(po['Vendor'] || 'Unknown').trim();
      const poDate = parseDate(String(po['Date'] || ''));
      
      if (!poDate) return;

      const poId = String(po[idHeader] || '').trim().toLowerCase();
      const rmCode = String(po['RM Code'] || '').trim().toLowerCase();

      const poLogs = allLogs.filter(log => {
        const logPoId = String(log[idHeader] || log['Bidso PO No'] || log['Bidso PO no'] || '').trim().toLowerCase();
        const logRmCode = String(log['RM Code'] || '').trim().toLowerCase();
        if (idHeader.toLowerCase().includes('unique') && logPoId === poId) return true;
        return logPoId === poId && logRmCode === rmCode;
      });

      if (poLogs.length > 0) {
        const inwardDates = poLogs
          .map(log => parseDate(String(log['Entry Date'] || '')))
          .filter(Boolean) as Date[];
          
        if (inwardDates.length > 0) {
          const earliestInward = new Date(Math.min(...inwardDates.map(d => d.getTime())));
          const diffDays = Math.ceil((earliestInward.getTime() - poDate.getTime()) / (1000 * 60 * 60 * 24));

          if (diffDays >= 0) {
            // RM + Vendor key
            const rvKey = `${rmName} || ${vendor}`;
            if (!rmVendorStats[rvKey]) {
              rmVendorStats[rvKey] = { totalDays: 0, count: 0, minDays: diffDays, maxDays: diffDays };
            }
            rmVendorStats[rvKey].totalDays += diffDays;
            rmVendorStats[rvKey].count += 1;
            rmVendorStats[rvKey].minDays = Math.min(rmVendorStats[rvKey].minDays, diffDays);
            rmVendorStats[rvKey].maxDays = Math.max(rmVendorStats[rvKey].maxDays, diffDays);

            // RM Only fallback
            if (!rmStats[rmName]) {
              rmStats[rmName] = { totalDays: 0, count: 0, minDays: diffDays, maxDays: diffDays };
            }
            rmStats[rmName].totalDays += diffDays;
            rmStats[rmName].count += 1;
            rmStats[rmName].minDays = Math.min(rmStats[rmName].minDays, diffDays);
            rmStats[rmName].maxDays = Math.max(rmStats[rmName].maxDays, diffDays);
          }
        }
      }
    });

    const vendorAnalysis = Object.entries(rmVendorStats).map(([key, data]) => {
      const [rm, v] = key.split(' || ');
      return {
        key,
        rmName: rm,
        vendor: v,
        avgDays: Math.round(data.totalDays / data.count),
        minDays: data.minDays,
        maxDays: data.maxDays,
        count: data.count,
        type: 'vendor-specific' as const
      };
    });

    const rmFallback = Object.entries(rmStats).map(([name, data]) => ({
      key: name,
      rmName: name,
      vendor: 'All Vendors',
      avgDays: Math.round(data.totalDays / data.count),
      minDays: data.minDays,
      maxDays: data.maxDays,
      count: data.count,
      type: 'material-average' as const
    }));

    return { 
      byVendor: vendorAnalysis.sort((a, b) => b.count - a.count), 
      byMaterial: rmFallback 
    };
  }, [enrichedPOs, logs, localLogs]);

  const availableYears = useMemo(() => {
    const years = new Set<string>();
    enrichedPOs.forEach(po => {
      if (Number(po['Order Quantity']) <= 0) return;
      const dateStr = String(po['Date'] || '');
      const date = parseDate(dateStr);
      if (date) {
        years.add(String(date.getFullYear()));
      }
    });
    return ['All', ...Array.from(years).sort((a, b) => b.localeCompare(a))];
  }, [enrichedPOs]);

  // Actions
  const handleInwardSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPO) return;

    const qty = parseFloat(newQty);
    if (isNaN(qty) || qty <= 0) {
      setError("Please enter a valid quantity.");
      return;
    }

    if (invUom === 'KG' && (!conversionFactor || isNaN(parseFloat(conversionFactor)))) {
      setError("Conversion factor (PCs/KG) is required when UOM is KG.");
      return;
    }

    // Use exact header names from user's PO tab
    const receivedQty = Number(currentPO['Received QTY']) || 0;
    const orderedQty = Number(currentPO['Order Quantity']) || 0;
    const poId = currentPO[idHeader] || '';
    const bidsoPONo = currentPO['Bidso PO no'] || '';
    const rmCode = currentPO['RM Code'] || '';
    const rmName = currentPO['RM Name'] || '';
    const plantName = currentPO['Plant Name'] || '';

    const totalAfter = receivedQty + qty;
    const limit = orderedQty * 1.05;

    if (totalAfter > limit) {
      setError(`Validation Error: Total received (${totalAfter}) exceeds 105% of ordered quantity (${limit.toFixed(0)}).`);
      return;
    }

    setIsSaving(true);

    // Success! Create log matching user's Inward_Logs tab headers
    const transactionId = `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
    
    const newLog: any = {
      'Entry Date': new Date().toISOString().split('T')[0],
      'Bidso PO No': bidsoPONo,
      'RM Code': rmCode,
      'RM Name': rmName,
      'New Received Quantity': qty,
      'Entry Note': '', // Placeholder for entry note if needed later
      'Plant Name': plantName,
      'Time stamp': new Date().toLocaleString(), // Using a readable string for timestamp
      'Unique ID': `${bidsoPONo} || ${rmCode}`, // Manually calculate Unique ID to ensure it extends in Sheets
      'User ID': user?.email || 'Unknown', // Track who made the entry
      'User Email': user?.email || 'Unknown', // Alias for matching
      'Email': user?.email || 'Unknown', // Alias for matching
      'Created By': user?.email || 'Unknown', // Alias for matching
      'transaction_id': transactionId, // Unique ID for deduplication
      'Transaction ID': transactionId, // Alias for matching
      'Inv UOM': invUom,
      'Conversion Factor': conversionFactor,
      '_createdAt': Date.now() // Internal timestamp for cleanup
    };

    try {
      // Add UOM & conversion factor to pending master updates queue
      const masterUpdate = {
        uniqueId: currentPO[idHeader],
        invUom: invUom || '',
        conversionFactor: (invUom === 'KG') ? (conversionFactor || '') : ''
      };
      
      setPendingMasterUpdates(prev => {
        const filtered = prev.filter(u => u.uniqueId !== currentPO[idHeader]);
        return [...filtered, masterUpdate];
      });

      // Add to local logs immediately for instant UI feedback and offline storage
      setLocalLogs(prev => [newLog, ...prev]);

      setIsSaving(false);
      setSuccess(true);
      
      // Trigger background sync without blocking the success UI if online
      if (typeof navigator !== 'undefined' && navigator.onLine) {
        setTimeout(() => {
          syncAll();
        }, 100);
      }

      // Auto-navigate back after success
      setTimeout(() => {
        resetWorkflow();
        setActiveTab('history');
      }, 1500);
    } catch (err: any) {
      setError(err.message || "Failed to save entry. Please try again.");
      console.error(err);
      setIsSaving(false);
    }
  };

  const resetWorkflow = () => {
    setWorkflowStep(1);
    setSelectedPlant('');
    setSelectedBidsoPO('');
    setSelectedRMCode('');
    setNewQty('');
    setError(null);
    setSuccess(false);
  };

  const syncAll = async (currentTokens?: any) => {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      console.warn('Sync skipped: Offline');
      setIsSyncing(false);
      return;
    }

    try {
      setIsSyncing(true);
      setError(null);

      const activeTokens = currentTokens || tokens;
      if (!activeTokens) {
        setIsSyncing(false);
        return;
      }

      // 1. Sync any pending local logs first of all
      if (localLogs.length > 0 && logHeaders.length > 0) {
        console.log(`Syncing ${localLogs.length} pending local logs to Google Sheets...`);
        const remainingLogs = [...localLogs];
        // Process from oldest to newest (i.e. from end of the array to front)
        while (remainingLogs.length > 0) {
          const localLog = remainingLogs[remainingLogs.length - 1];
          const rowValues = logHeaders.map(header => {
            const normalizedHeader = header.toLowerCase().replace(/[^a-z0-9]/g, '');
            const key = Object.keys(localLog).find(k => k.toLowerCase().replace(/[^a-z0-9]/g, '') === normalizedHeader);
            return key ? localLog[key] : '';
          });
          
          const { error: logSyncError } = await ApiService.appendSheetData('Inward_Logs!A:Z', [rowValues], activeTokens);
          if (logSyncError) {
            console.error('Local log sync encountered an issue, will retry next time:', logSyncError);
            break; 
          }
          remainingLogs.pop();
          setLocalLogs([...remainingLogs]);
        }
      }

      // 2. Sync any pending master PO updates (UOM & PCs/KG conversions)
      if (pendingMasterUpdates.length > 0) {
        console.log(`Syncing ${pendingMasterUpdates.length} pending master updates to Google Sheets...`);
        const { data: sheetData, error: getMasterError } = await ApiService.getSheetData('Historical PO Data!A:Z', activeTokens);
        
        if (!getMasterError && sheetData && sheetData.length > 0) {
          const headerRowIdx = sheetData.findIndex((row: any[]) => 
            row && row.length > 0 && row.some(cell => String(cell || '').toLowerCase().includes('unique id'))
          );
          
          if (headerRowIdx !== -1) {
            const headers = sheetData[headerRowIdx].map((h: any) => String(h || '').trim());
            const idIdx = headers.findIndex(h => h.toLowerCase().includes('unique id'));
            const uomIdx = headers.findIndex(h => h.toLowerCase().includes('inv uom'));
            const factorIdx = headers.findIndex(h => h.toLowerCase().includes('conversion factor'));

            if (idIdx !== -1 && uomIdx !== -1 && factorIdx !== -1) {
              const dataRows = sheetData.slice(headerRowIdx + 1);
              const remainingUpdates = [...pendingMasterUpdates];
              
              while (remainingUpdates.length > 0) {
                const update = remainingUpdates[0];
                const uniqueIdToMatch = String(update.uniqueId || '').trim();
                const dataRowIdx = dataRows.findIndex(row => String(row[idIdx] || '').trim() === uniqueIdToMatch);
                
                if (dataRowIdx !== -1) {
                  const absoluteRowIndex = headerRowIdx + dataRowIdx + 1;
                  const updatedRow = [...sheetData[absoluteRowIndex]];
                  const maxIdxNeeded = Math.max(uomIdx, factorIdx);
                  while (updatedRow.length <= maxIdxNeeded) updatedRow.push('');
                  
                  updatedRow[uomIdx] = update.invUom || '';
                  updatedRow[factorIdx] = update.conversionFactor || '';

                  const { error: masterSyncError } = await ApiService.updateSheetData(
                    `Historical PO Data!A${absoluteRowIndex + 1}:Z${absoluteRowIndex + 1}`,
                    [updatedRow],
                    activeTokens
                  );
                  if (masterSyncError) {
                    console.error('Master update sync encountered an issue, will retry:', masterSyncError);
                    break;
                  }
                }
                remainingUpdates.shift();
                setPendingMasterUpdates([...remainingUpdates]);
              }
            }
          }
        }
      }

      // 3. Normal batch download of POs and Logs
      const ranges = ['Historical PO Data!A:Z', 'Inward_Logs!A:Z'];
      const { data, error: syncError } = await ApiService.batchGetSheetData(ranges, activeTokens);

      if (syncError) {
        if (syncError.toLowerCase().includes('unauthorized') || syncError.toLowerCase().includes('token') || syncError.toLowerCase().includes('expired')) {
          console.warn('Sync unauthorized, checking auth...');
          checkAuth(activeTokens);
          return;
        }
        throw new Error(syncError);
      }
      
      if (!data) {
        setIsSyncing(false);
        return;
      }

      // --- Process PO Data ---
      const poData = data['Historical PO Data!A:Z'];
      if (poData) {
        const headerRowIndex = poData.findIndex((row: any[]) => row && row.length > 0 && row.some(cell => cell && String(cell).trim() !== ''));
        if (headerRowIndex !== -1) {
          const headers = poData[headerRowIndex].map((h: any) => String(h || '').trim());
          setPoHeaders(headers);
          
          const foundIdHeader = headers.find((h: string) => 
            ['unique id', 'id', 'po number', 'po no', 'bidso po no', 'bidso po number'].includes(h.toLowerCase())
          ) || headers[0];
          setIdHeader(foundIdHeader);

          const rows = poData.slice(headerRowIndex + 1).map((row: any[]) => {
            const obj: any = {};
            headers.forEach((header: string, index: number) => {
              obj[header] = row[index];
            });
            return obj;
          }).filter((item: any) => {
            const idValue = item[foundIdHeader];
            return idValue && String(idValue).trim() !== '';
          });
          setPos(rows);
        }
      }

      // --- Process Logs Data ---
      const logsData = data['Inward_Logs!A:Z'];
      if (logsData) {
        const headerRowIndex = logsData.findIndex((row: any[]) => row && row.length > 0 && row.some(cell => cell && String(cell).trim() !== ''));
        if (headerRowIndex !== -1) {
          const headers = logsData[headerRowIndex].map((h: any) => String(h || '').trim());
          setLogHeaders(headers);
          
          const rows = logsData.slice(headerRowIndex + 1).map((row: any[]) => {
            const obj: any = {};
            headers.forEach((header: string, index: number) => {
              obj[header] = row[index];
            });
            return obj;
          }).filter((item: any) => {
            return Object.values(item).some(val => val && String(val).trim() !== '');
          }).reverse();
          setLogs(rows);

          // Cleanup local logs using transaction_id for exact matching
          setLocalLogs(prev => prev.filter(local => {
            const localTxnId = local['transaction_id'] || local['Transaction ID'];
            if (!localTxnId) return true; // Fallback if no ID

            const isSynced = rows.some(fetched => {
              const fetchedTxnId = fetched['transaction_id'] || fetched['Transaction ID'];
              return String(fetchedTxnId) === String(localTxnId);
            });
            return !isSynced;
          }));
        }
      }

      setIsSyncing(false);

      // --- Automatic Sheet Cleanup (Sync-time Automation) ---
      if (activeTokens && poData && poData.length > 0 && logsData && logsData.length > 0 && hasPermission) {
        (async () => {
          try {
            const hIdx = poData.findIndex((r: any[]) => r && r.length > 0 && r.some(c => String(c||'').trim() !== ''));
            if (hIdx === -1) return;
            const headers = poData[hIdx].map((h: any) => String(h || '').trim());
            
            const logHIdx = logsData.findIndex((r: any[]) => r && r.length > 0 && r.some(c => String(c||'').trim() !== ''));
            if (logHIdx === -1) return;
            const logHeaders = logsData[logHIdx].map((h: any) => String(h || '').trim());

            const dateIdx = headers.findIndex(h => h.toLowerCase() === 'date');
            const expDateIdx = headers.findIndex(h => h.toLowerCase().includes('expected delivery date'));
            const rmNameIdx = headers.findIndex(h => h.toLowerCase().includes('rm name'));
            const vendorIdx = headers.findIndex(h => h.toLowerCase().includes('vendor') || h.toLowerCase().includes('supplier'));
            const rmCodeIdx = headers.findIndex(h => h.toLowerCase().includes('rm code'));
            const idIdx = headers.findIndex(h => h.toLowerCase().includes('unique id') || h.toLowerCase() === 'id');
            const bidsoPoIdx = headers.findIndex(h => h.toLowerCase().includes('bidso po no') || h.toLowerCase().includes('po number'));

            if (dateIdx === -1 || expDateIdx === -1 || rmNameIdx === -1) return;

            const logDateIdx = logHeaders.findIndex(h => h.toLowerCase().includes('entry date'));
            const logPoIdx = logHeaders.findIndex(h => h.toLowerCase().includes('bidso po no') || h.toLowerCase().includes('unique id'));
            const logRmIdx = logHeaders.findIndex(h => h.toLowerCase().includes('rm code'));

            const poRows = poData.slice(hIdx + 1);
            const logRows = logsData.slice(logHIdx + 1);

            // 1. Calculate Lead Times from raw data: Vendor+RM and RM fallbacks
            const rvStats: Record<string, { total: number, count: number }> = {};
            const rStats: Record<string, { total: number, count: number }> = {};

            poRows.forEach(row => {
              const poDate = parseDate(String(row[dateIdx] || ''));
              if (!poDate) return;

              const rmName = String(row[rmNameIdx] || '').trim();
              const vendor = vendorIdx !== -1 ? String(row[vendorIdx] || '').trim() : '';
              const pUniqueId = String(row[idIdx] || '').trim().toLowerCase();
              const pBidsoPo = String(row[bidsoPoIdx] || '').trim().toLowerCase();
              const pRmCode = String(row[rmCodeIdx] || '').trim().toLowerCase();

              const matchingLogs = logRows.filter(lRow => {
                const lPoId = String(lRow[logPoIdx] || '').trim().toLowerCase();
                const lRmCode = String(lRow[logRmIdx] || '').trim().toLowerCase();
                if (pUniqueId && lPoId === pUniqueId) return true;
                return pBidsoPo && lPoId === pBidsoPo && lRmCode === pRmCode;
              });

              if (matchingLogs.length > 0) {
                const dates = matchingLogs.map(l => parseDate(String(l[logDateIdx] || ''))).filter(Boolean) as Date[];
                if (dates.length > 0) {
                  const earliest = new Date(Math.min(...dates.map(d => d.getTime())));
                  const diff = Math.ceil((earliest.getTime() - poDate.getTime()) / (1000 * 60 * 60 * 24));
                  if (diff >= 0) {
                    // RV Keyed stats
                    if (vendor) {
                      const rvKey = `${rmName}||${vendor}`;
                      if (!rvStats[rvKey]) rvStats[rvKey] = { total: 0, count: 0 };
                      rvStats[rvKey].total += diff;
                      rvStats[rvKey].count += 1;
                    }
                    // Material fallback
                    if (!rStats[rmName]) rStats[rmName] = { total: 0, count: 0 };
                    rStats[rmName].total += diff;
                    rStats[rmName].count += 1;
                  }
                }
              }
            });

            // 2. Find missing dates and update
            const updates = [];
            for (let i = 0; i < poRows.length; i++) {
              const row = poRows[i];
              if (!String(row[expDateIdx] || '').trim()) {
                const rmName = String(row[rmNameIdx] || '').trim();
                const vendor = vendorIdx !== -1 ? String(row[vendorIdx] || '').trim() : '';
                
                // Try Vendor specific first, then material average
                const stats = (vendor ? rvStats[`${rmName}||${vendor}`] : null) || rStats[rmName];
                
                if (stats) {
                  const poDate = parseDate(String(row[dateIdx] || ''));
                  if (poDate) {
                    const avg = Math.round(stats.total / stats.count);
                    const pred = new Date(poDate);
                    pred.setDate(pred.getDate() + avg);
                    const predStr = pred.toISOString().split('T')[0];
                    
                    const updatedRow = [...row];
                    updatedRow[expDateIdx] = predStr;
                    const rowIndex = hIdx + i + 2;
                    updates.push({
                      range: `Historical PO Data!A${rowIndex}:Z${rowIndex}`,
                      values: [updatedRow]
                    });
                  }
                }
              }
            }

            // 3. Apply updates using batch update
            if (updates.length > 0) {
              console.log(`Sync-time Automation: Found ${updates.length} missing delivery dates. Batch updating...`);
              // Use batch update to process all missing dates efficiently in a single request
              await ApiService.batchUpdateSheetData(updates, activeTokens);
            }
          } catch (cleanupErr) {
            console.error('Background cleanup failed:', cleanupErr);
          }
        })();
      }
    } catch (err: any) {
      console.error('Sync error:', err);
      setError(err.message || 'Failed to sync with Google Sheets');
      setIsSyncing(false);
    }
  };

  // Swipe Navigation Logic
  const tabs: ('history' | 'inward' | 'logs' | 'analysis')[] = ['history', 'inward', 'logs', 'analysis'];
  const handleSwipe = (direction: 'left' | 'right') => {
    const currentIndex = tabs.indexOf(activeTab as any);
    let targetTab: string | null = null;
    
    if (direction === 'left' && currentIndex < tabs.length - 1) {
      targetTab = tabs[currentIndex + 1];
    } else if (direction === 'right' && currentIndex > 0) {
      targetTab = tabs[currentIndex - 1];
    }

    if (targetTab) {
      setActiveTab(targetTab as any);
      if (targetTab === 'history') resetWorkflow();
    }
  };

  const mainTabs = [
    { id: 'history', label: 'History', icon: <Database className="w-5 h-5" /> },
    { id: 'inward', label: 'Inward', icon: <PlusCircle className="w-5 h-5" /> },
    { id: 'logs', label: 'Logs', icon: <List className="w-5 h-5" /> },
    { id: 'analysis', label: 'Analysis', icon: <BarChart3 className="w-5 h-5" /> },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  if (isCheckingAuth) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-center">
        <div className="relative">
          <div className="absolute inset-0 bg-brand-500/20 blur-2xl rounded-full animate-pulse"></div>
          <Loader2 className="w-12 h-12 text-brand-600 animate-spin mb-6 relative z-10" />
        </div>
        <div className="space-y-2 relative z-10">
          <p className="font-display font-bold text-xl text-slate-800">Warehouse Portal</p>
          <p className="text-slate-400 text-sm font-medium tracking-wide uppercase">Verifying Session...</p>
          {authError && (
            <div className="mt-4 p-3 bg-rose-50 border border-rose-100 rounded-xl flex items-center gap-2 max-w-sm mx-auto">
              <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
              <p className="text-xs text-rose-600 font-medium">{authError}</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
        <Card className="max-w-md w-full p-8 text-center space-y-6 shadow-xl border-none">
          <div className="w-20 h-20 bg-indigo-600 rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-indigo-200">
            <Lock className="text-white w-10 h-10" />
          </div>
          <div className="space-y-2">
            <h1 className="text-2xl font-black text-slate-800">Warehouse Portal</h1>
            <p className="text-slate-500">Please sign in with your company email to access the PO system.</p>
          </div>
          <button 
            onClick={handleLogin}
            className="w-full bg-white border border-slate-200 hover:border-brand-200 hover:bg-brand-50/30 text-slate-700 font-display font-bold py-4 rounded-2xl flex items-center justify-center gap-3 transition-all group shadow-sm active:scale-[0.98]"
          >
            <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" />
            <span>Sign in with Google</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform text-brand-500" />
          </button>

          <div className="pt-4 border-t border-slate-50 text-left space-y-2">
            <h3 className="text-xs font-bold text-slate-800 uppercase tracking-widest flex items-center gap-1.5"><ShieldAlert className="w-3.5 h-3.5 text-indigo-500" /> Prerequisites to Use</h3>
            <ul className="text-xs text-slate-500 space-y-1.5 pl-5 list-disc">
              <li>Must use authorized company email account.</li>
              <li>Must have at least <b>Editor</b> permissions on the Master PO Tracker Google Sheet.</li>
              <li>Must accept Google Workspace integration scopes for Calendar and Sheets access.</li>
            </ul>
          </div>

          <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest mt-2">Enterprise Security Enabled</p>
        </Card>
      </div>
    );
  }

  if (hasPermission === false) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6">
        <Card className="max-w-md w-full p-8 text-center space-y-6 shadow-xl border-none">
          <div className="w-20 h-20 bg-rose-100 rounded-2xl flex items-center justify-center mx-auto">
            <ShieldAlert className="text-rose-600 w-10 h-10" />
          </div>
          <div className="space-y-2">
            <h1 className="text-2xl font-black text-slate-800">Access Denied</h1>
            <p className="text-slate-500">
              Your account (<b>{user.email}</b>) does not have "Editor" permissions for the master PO sheet.
            </p>
          </div>
          <div className="bg-rose-50 p-4 rounded-xl text-left text-sm text-rose-800 border border-rose-100">
            <p className="font-bold mb-1">Required Action:</p>
            <p>Please contact your System Administrator to request <b>Editor Access</b> for the Google Sheet.</p>
          </div>
          <div className="flex gap-3">
            <button 
              onClick={() => checkAuth()}
              className="flex-1 bg-brand-600 text-white font-display font-bold py-3.5 rounded-2xl hover:bg-brand-700 transition-all shadow-lg shadow-brand-100 active:scale-[0.98]"
            >
              Retry Access
            </button>
            <button 
              onClick={handleLogout}
              className="px-5 py-3.5 border border-slate-200 rounded-2xl hover:bg-slate-50 text-slate-400 hover:text-slate-600 transition-all active:scale-[0.98]"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <motion.div 
      className="min-h-screen bg-slate-50 pb-24 font-sans text-slate-900 selection:bg-brand-100 touch-pan-y"
      onPanEnd={onGestureSwipe}
    >
      <Header 
        user={user} 
        isSyncing={isSyncing} 
        onSync={() => syncAll()} 
        onLogout={handleLogout} 
        onMenuClick={() => setIsMenuOpen(true)}
      />
      <AppMenu isOpen={isMenuOpen} onClose={() => setIsMenuOpen(false)} />

      {/* Offline Banner */}
      <AnimatePresence>
        {!isOnline && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="bg-amber-500 text-white overflow-hidden"
          >
            <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-center gap-2.5 text-[11px] font-bold uppercase tracking-widest text-center">
              <CloudOff className="w-4 h-4 animate-bounce" />
              <span>Offline Mode • Entries are saved locally and will sync automatically when connection restores</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Desktop Navigation */}
      <div className="hidden lg:block fixed left-8 top-28 w-56 space-y-2">
        {mainTabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`w-full flex items-center gap-3 px-5 py-4 rounded-2xl transition-all duration-300 ${
              activeTab === tab.id 
                ? 'bg-brand-600 text-white shadow-xl shadow-brand-200 translate-x-2' 
                : 'text-slate-500 hover:bg-white hover:text-brand-600 hover:shadow-sm'
            }`}
          >
            {React.cloneElement(tab.icon as React.ReactElement<any>, { className: 'w-5 h-5' })}
            <span className="font-display font-bold text-sm tracking-tight">{tab.label}</span>
          </button>
        ))}
      </div>

      <main className="max-w-4xl mx-auto p-4 sm:p-6 pb-32 sm:pb-40">
        {error && (
          <div className="mb-6 p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 space-y-3">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Connection Error</p>
                <p className="text-sm opacity-90">{error}</p>
              </div>
            </div>
          </div>
        )}

        <AnimatePresence mode="popLayout">
          {activeTab === 'history' ? (
            <motion.div 
              key="history"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="space-y-4"
            >
              <div className="space-y-1 mb-6">
                <h2 className="font-display font-bold text-2xl tracking-tight text-slate-800">Purchase Orders</h2>
                <p className="text-sm text-slate-400 font-medium">Track and manage your material orders.</p>
              </div>

              {/* Search Bar */}
              <div className="relative group">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-brand-500 transition-colors" />
                <input 
                  type="text"
                  placeholder="Search PO, RM Code, Vendor..."
                  className="premium-input pl-12"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              {/* PO List */}
              <motion.div 
                variants={containerVariants}
                initial="hidden"
                animate="show"
                className="space-y-3"
              >
                {pos.length === 0 && !isSyncing && !error && (
                  <motion.div variants={itemVariants} className="p-12 bg-white border border-slate-200/60 rounded-3xl text-center space-y-4 shadow-sm">
                    <div className="w-20 h-20 bg-amber-50 rounded-full flex items-center justify-center mx-auto">
                      <Database className="w-10 h-10 text-amber-400 opacity-80" />
                    </div>
                    <div className="space-y-2">
                      <h3 className="font-display font-bold text-xl text-slate-800">No PO Data Loaded</h3>
                      <p className="text-sm text-slate-500 max-w-xs mx-auto">The app connected to your sheet, but couldn't find any rows with a <b className="text-brand-600">"{idHeader}"</b>.</p>
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono bg-slate-50 p-3 rounded-xl border border-slate-100 max-w-md mx-auto overflow-x-auto">
                      Detected Headers: {poHeaders.join(', ') || 'None'}
                    </div>
                    <button 
                      onClick={() => syncAll()}
                      className="inline-flex items-center gap-2 px-6 py-3 bg-brand-600 text-white rounded-xl font-bold shadow-lg shadow-brand-100 hover:bg-brand-700 transition-all active:scale-95 mx-auto"
                    >
                      <RefreshCw className="w-4 h-4" />
                      <span>Sync Now</span>
                    </button>
                  </motion.div>
                )}

                {filteredPOs.length > 0 ? (
                  filteredPOs.map((po, idx) => (
                    <motion.div key={po[idHeader] || idx} variants={itemVariants}>
                      <Card className="border-l-4 border-r-4 border-brand-500 hover:border-brand-200 active:border-brand-300 hover:shadow-xl active:shadow-2xl hover:shadow-brand-900/5 active:shadow-brand-900/10 active:bg-slate-50/50 transition-all cursor-pointer group active:scale-[0.97]" onClick={() => {
                        setSelectedHistoryPO(po);
                      }}>
                       <div className="p-5">
                        <div className="mb-4">
                          <div className="flex justify-between items-center gap-3">
                            <h3 className="font-display font-bold text-lg text-slate-800 group-hover:text-brand-600 transition-colors truncate flex-1" title={po[idHeader]}>{po[idHeader]}</h3>
                            <div className="flex-shrink-0">
                              <Badge variant={Number(po['Received QTY']) >= Number(po['Order Quantity']) ? 'success' : Number(po['Received QTY']) > 0 ? 'warning' : 'default'}>
                                {Number(po['Received QTY']) >= Number(po['Order Quantity']) ? 'Completed' : Number(po['Received QTY']) > 0 ? 'Partial' : 'Pending'}
                              </Badge>
                            </div>
                          </div>
                          <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest leading-tight whitespace-normal break-words mt-1" title={po['RM Name']}>{po['RM Name']}</p>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-x-6 gap-y-4 text-xs">
                          <div className="flex items-start gap-2.5 text-slate-600">
                            <div className="p-1.5 bg-slate-50 rounded-lg group-hover:bg-brand-50 transition-colors">
                              <Factory className="w-3.5 h-3.5 text-slate-400 group-hover:text-brand-500" />
                            </div>
                            <span className="font-medium leading-relaxed">{po['Plant Name']}</span>
                          </div>
                          <div className="flex items-start gap-2.5 text-slate-600">
                            <div className="p-1.5 bg-slate-50 rounded-lg group-hover:bg-brand-50 transition-colors">
                              <User className="w-3.5 h-3.5 text-slate-400 group-hover:text-brand-500" />
                            </div>
                            <span className="font-medium leading-relaxed">{po['Vendor']}</span>
                          </div>

                          {/* Row 2 */}
                          <div className="flex items-center gap-2.5 text-slate-600">
                            <div className="p-1.5 bg-slate-50 rounded-lg group-hover:bg-brand-50 transition-colors">
                              <IndianRupee className="w-3.5 h-3.5 text-slate-400 group-hover:text-brand-500" />
                            </div>
                            <span className="font-medium">₹{po['Price']}</span>
                          </div>
                          <div className="flex items-center gap-2.5 text-slate-600">
                            <div className="p-1.5 bg-slate-50 rounded-lg group-hover:bg-brand-50 transition-colors">
                              <Calendar className="w-3.5 h-3.5 text-slate-400 group-hover:text-brand-500" />
                            </div>
                            <span className="font-medium">{formatDate(String(po['Date']))}</span>
                          </div>

                          {/* Row 3 */}
                          <div className="flex items-start gap-2.5 text-slate-600 pt-3 border-t border-slate-100">
                            <div className="p-1.5 bg-slate-50 rounded-lg group-hover:bg-brand-50 transition-colors">
                              <MessageSquare className="w-3.5 h-3.5 text-slate-400 group-hover:text-brand-500" />
                            </div>
                            <span className="text-[11px] leading-relaxed break-words line-clamp-2 italic text-slate-500" title={po['Special Remark']}>
                              {po['Special Remark'] || "No remarks"}
                            </span>
                          </div>
                          <div className="flex items-center gap-2.5 text-slate-600 pt-3 border-t border-slate-100">
                            <div className="p-1.5 bg-slate-50 rounded-lg group-hover:bg-brand-50 transition-colors">
                              <Truck className="w-3.5 h-3.5 text-slate-400 group-hover:text-brand-500" />
                            </div>
                            <div className="flex flex-col">
                              <DateDisplay label="" date={String(po['Expected delivery date'] || '')} />
                            </div>
                          </div>
                        </div>

                        <div className="mt-4 pt-4 border-t border-slate-100">
                          <div className="flex justify-between items-center text-[10px] mb-2 relative">
                            <span className="text-slate-400 uppercase font-black tracking-widest">Inward Progress</span>
                            <span className="absolute left-1/2 -translate-x-1/2 font-black text-brand-600 bg-brand-50 px-2 py-0.5 rounded-lg text-[9px] tracking-tighter">
                              {po['Order Quantity'] ? Math.round((Number(po['Received QTY']) / Number(po['Order Quantity'])) * 100) : 0}%
                            </span>
                            <span className="font-black text-brand-600 tracking-tighter">{po['Received QTY']} / {po['Order Quantity']}</span>
                          </div>
                          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${Math.min((Number(po['Received QTY']) / Number(po['Order Quantity'])) * 100, 100)}%` }}
                              className={`h-full rounded-full ${Number(po['Received QTY']) >= Number(po['Order Quantity']) ? 'bg-emerald-500' : 'bg-brand-600'}`}
                            />
                          </div>
                          <div className="flex justify-between mt-2 text-[10px] text-slate-400 uppercase font-medium relative">
                            <div className="flex flex-col">
                              <span>Diff: {po['Diff'] || (Number(po['Order Quantity']) - Number(po['Received QTY']))}</span>
                              {showDebug && (
                                <span className="text-indigo-400 font-mono lowercase mt-0.5">
                                  (Base: {po._debug.base} + Logs: {po._debug.logs})
                                </span>
                              )}
                            </div>
                            
                            <div className="absolute left-1/2 -translate-x-1/2 top-0">
                              {String(po['System PO Generated'] || '').toLowerCase() === 'yes' ? (
                                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[8px] font-bold bg-[#15803d] text-white shadow-sm">
                                  Sys PO: Yes
                                </span>
                              ) : (
                                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[8px] font-bold bg-[#b91c1c] text-white shadow-sm">
                                  Sys PO: NO
                                </span>
                              )}
                            </div>

                            <span>Limit: {(Number(po['Order Quantity']) * 1.05).toFixed(0)} (105%)</span>
                          </div>
                        </div>
                      </div>
                    </Card>
                    </motion.div>
                  ))
                ) : (
                  <motion.div variants={itemVariants} className="text-center py-12 text-slate-400">
                    <Search className="w-12 h-12 mx-auto mb-3 opacity-20" />
                    <p>No POs found matching your search.</p>
                  </motion.div>
                )}
              </motion.div>

              {/* Debug Toggle */}
              <div className="pt-4 flex justify-center">
                <button 
                  onClick={() => setShowDebug(!showDebug)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-bold transition-all ${
                    showDebug 
                      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' 
                      : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                  }`}
                >
                  <Info className="w-3 h-3" />
                  {showDebug ? 'Hide Debug Data' : 'Show Debug Data'}
                </button>
              </div>
            </motion.div>
          ) : activeTab === 'inward' ? (
            <motion.div 
              key="inward"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="space-y-6"
            >
              <div className="space-y-1 mb-6">
                <h2 className="font-display font-bold text-2xl tracking-tight text-slate-800">Material Inward</h2>
                <p className="text-sm text-slate-400 font-medium">Record new material receipts at the warehouse.</p>
              </div>

              {success ? (
                <div className="bg-white p-8 rounded-2xl border border-emerald-100 shadow-xl text-center space-y-4">
                  <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                  <h2 className="text-2xl font-bold text-slate-800">Inward Logged!</h2>
                  <p className="text-slate-500">The receipt has been recorded and the PO progress updated.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Step Progress Indicator */}
                  <div className="mb-8">
                    <div className="flex justify-between items-end mb-2.5 px-0.5">
                      <div className="space-y-0.5">
                        <span className={`text-[10px] font-black uppercase tracking-wider block ${workflowStep >= 1 ? 'text-brand-600' : 'text-slate-300'}`}>Stage 01</span>
                        <h3 className={`text-[11px] font-bold ${workflowStep >= 1 ? 'text-slate-600' : 'text-slate-300'}`}>Identification</h3>
                      </div>
                      <div className="space-y-0.5 text-right">
                        <span className={`text-[10px] font-black uppercase tracking-wider block ${workflowStep >= 2 ? 'text-brand-600' : 'text-slate-300'}`}>Stage 02</span>
                        <h3 className={`text-[11px] font-bold ${workflowStep >= 2 ? 'text-slate-600' : 'text-slate-300'}`}>Receipt Entry</h3>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {[1, 2].map(step => (
                        <div 
                          key={step} 
                          className={`h-1.5 flex-1 rounded-full transition-all duration-700 ${workflowStep >= step ? 'bg-brand-600 shadow-sm shadow-brand-100' : 'bg-slate-100'}`}
                        />
                      ))}
                    </div>
                  </div>

                  {workflowStep === 1 ? (
                    <Card className="p-8 space-y-8">
                      <div className="space-y-1">
                        <h2 className="font-display font-bold text-2xl text-slate-800 tracking-tight">Initiate Inward</h2>
                        <p className="text-[15px] text-slate-400 font-medium">Select the plant and PO to begin entry.</p>
                      </div>

                      <div className="space-y-6">
                          <div className="space-y-2.5">
                            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                              <Factory className="w-3.5 h-3.5" /> Plant Name
                            </label>
                            <div className="relative group">
                              <select 
                                className="premium-input text-sm bg-slate-50/50 appearance-none pr-10"
                                value={selectedPlant}
                                onChange={(e) => {
                                  setSelectedPlant(e.target.value);
                                  setSelectedBidsoPO('');
                                  setPoSearchQuery('');
                                  setSelectedRMCode('');
                                }}
                              >
                                <option value="">Select Plant</option>
                                {plants.map(p => <option key={p} value={p}>{p}</option>)}
                              </select>
                              <ChevronDown className="w-4 h-4 text-slate-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none group-hover:text-brand-500 transition-colors" />
                            </div>
                          </div>

                        <div className={`space-y-2.5 transition-all duration-300 ${!selectedPlant ? 'opacity-40 pointer-events-none' : ''}`}>
                          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                            <FileText className="w-3.5 h-3.5" /> Bidso PO No
                          </label>
                          <div className="space-y-3">
                            <div className="relative group">
                              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-brand-500 transition-colors" />
                              <input 
                                type="text"
                                placeholder="Search PO No..."
                                className="premium-input text-sm pl-12 bg-slate-50/50"
                                value={poSearchQuery}
                                onChange={(e) => setPoSearchQuery(e.target.value)}
                              />
                            </div>
                            <div className="relative group">
                              <select 
                                className="premium-input text-sm bg-slate-50/50 appearance-none pr-10"
                                value={selectedBidsoPO}
                                onChange={(e) => {
                                  setSelectedBidsoPO(e.target.value);
                                  setPoSearchQuery('');
                                  setSelectedRMCode('');
                                }}
                              >
                                <option value="">{poSearchQuery ? `Results for "${poSearchQuery}"` : "Select PO No"}</option>
                                {availableBidsoPOs
                                  .filter(po => po.toLowerCase().includes(poSearchQuery.toLowerCase()))
                                  .map(po => <option key={po} value={po}>{po}</option>)}
                                {availableBidsoPOs.filter(po => po.toLowerCase().includes(poSearchQuery.toLowerCase())).length === 0 && (
                                  <option disabled>No matching POs found</option>
                                )}
                              </select>
                              <ChevronDown className="w-4 h-4 text-slate-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none group-hover:text-brand-500 transition-colors" />
                            </div>
                          </div>
                        </div>

                        <div className={`space-y-2.5 transition-all duration-300 ${!selectedBidsoPO ? 'opacity-40 pointer-events-none' : ''}`}>
                          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                            <Package className="w-3.5 h-3.5" /> RM Code
                          </label>
                          <div className="relative group">
                            <select 
                              className="premium-input text-sm bg-slate-50/50 appearance-none pr-10"
                              value={selectedRMCode}
                              onChange={(e) => setSelectedRMCode(e.target.value)}
                            >
                              <option value="">Select RM Code</option>
                              {availableRMCodes.map(p => <option key={p['RM Code']} value={p['RM Code']}>{p['RM Code']} - {p['RM Name']}</option>)}
                            </select>
                              <ChevronDown className="w-4 h-4 text-slate-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none group-hover:text-brand-500 transition-colors" />
                          </div>
                        </div>
                      </div>

                      <button 
                        disabled={!selectedRMCode}
                        onClick={() => setWorkflowStep(2)}
                        className="w-full bg-brand-600 text-white py-4 rounded-2xl font-display font-bold shadow-xl shadow-brand-200 hover:bg-brand-700 transition-all active:scale-[0.98] disabled:bg-slate-200 disabled:text-slate-400 disabled:shadow-none flex items-center justify-center gap-2"
                      >
                        <span>Review & Enter</span> <ArrowRight className="w-5 h-5" />
                      </button>
                    </Card>
                  ) : (
                    <div className="space-y-4">
                      <button 
                        onClick={() => setWorkflowStep(1)}
                        className="flex items-center gap-2 text-[14px] font-bold text-slate-400 hover:text-brand-600 transition-all active:scale-95"
                      >
                        <ArrowLeft className="w-4 h-4" /> Back to Selection
                      </button>

                      <Card className="p-0 border-none shadow-2xl shadow-slate-200/60 overflow-hidden">
                        <div className="bg-slate-50/50 p-5 sm:p-6 border-b border-slate-100">
                          <h2 className="font-display font-bold text-xl sm:text-2xl text-slate-800 tracking-tight mb-1">{currentPO?.[idHeader]}</h2>
                          <p className="text-[12px] text-slate-500 font-bold leading-tight whitespace-normal break-words mt-1">{currentPO?.['RM Name']}</p>
                        </div>
                        
                        <div className="p-5 sm:p-6 grid grid-cols-2 sm:grid-cols-3 gap-y-4 gap-x-6">
                          <div className="space-y-1">
                            <p className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">Vendor</p>
                            <p className="text-[14px] font-bold text-slate-700 truncate" title={currentPO?.['Vendor']}>{currentPO?.['Vendor']}</p>
                          </div>
                          <div className="space-y-1">
                            <p className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">Price</p>
                            <p className="text-[14px] font-bold text-slate-700">₹{currentPO?.['Price']}</p>
                          </div>
                          <div className="space-y-1">
                            <p className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">Order Qty</p>
                            <p className="text-[14px] font-bold text-slate-700">{currentPO?.['Order Quantity']}</p>
                          </div>
                          <div className="space-y-1">
                            <p className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">Already Received</p>
                            <p className="text-[14px] font-black text-brand-600">{currentPO?.['Received QTY']}</p>
                          </div>
                          <div className="space-y-1">
                            <p className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">Balance</p>
                            <p className="text-[14px] font-bold text-slate-800">{currentPO?.['Diff']}</p>
                          </div>
                          <div className="space-y-1">
                            <p className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">System PO</p>
                            <div className="pt-0.5">
                              {String(currentPO?.['System PO Generated'] || '').toLowerCase() === 'yes' ? (
                                <Badge variant="success">Yes</Badge>
                              ) : (
                                <Badge variant="danger">No</Badge>
                              )}
                            </div>
                          </div>
                          <div className="col-span-full space-y-1 pt-1">
                            <p className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">Special Remark</p>
                            <p className="text-[12px] text-slate-500 italic font-medium leading-tight">{currentPO?.['Special Remark'] || "No remarks provided."}</p>
                          </div>
                        </div>

                        <div className="p-5 sm:p-6 bg-brand-50/20 border-t border-brand-100/50">
                          <form onSubmit={handleInwardSubmit} className="space-y-5">
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <label className="text-[10px] font-bold uppercase tracking-widest text-brand-900/40">Inv UOM</label>
                                <select 
                                  className="premium-input py-2.5 text-sm"
                                  value={invUom}
                                  onChange={(e) => setInvUom(e.target.value)}
                                  required
                                >
                                  <option value="" disabled>Select Unit</option>
                                  <option value="KG">KG</option>
                                  <option value="PCs">PCs</option>
                                </select>
                              </div>
                              <div className="space-y-2">
                                <label className="text-[10px] font-bold uppercase tracking-widest text-brand-900/40">PCs / KG Ratio</label>
                                <input 
                                  type="number"
                                  step="0.001"
                                  placeholder="Ratio"
                                  className="premium-input py-2.5 text-sm"
                                  value={conversionFactor}
                                  onChange={(e) => setConversionFactor(e.target.value)}
                                  disabled={invUom === 'PCs'}
                                />
                              </div>
                            </div>

                            <div className="space-y-2 relative">
                              <label className="text-[10px] font-bold uppercase tracking-widest text-brand-900/40 text-center block">New Receipt Qty {invUom ? `(${invUom})` : ''}</label>
                              <input 
                                type="number"
                                step="1"
                                placeholder="0"
                                onKeyDown={(e) => {
                                  if (e.key === '.' || e.key === ',') e.preventDefault();
                                }}
                                className={`premium-input font-display font-bold text-2xl py-4 text-center transition-all ${
                                  Number(newQty) > Number(currentPO?.['Diff']) 
                                    ? 'bg-rose-50 border-rose-200 text-rose-600 focus:ring-rose-500/20' 
                                    : Number(newQty) > 0 && Number(newQty) === Number(currentPO?.['Diff'])
                                      ? 'bg-emerald-50 border-emerald-200 text-emerald-600 focus:ring-emerald-500/20'
                                      : 'bg-white'
                                }`}
                                value={newQty}
                                onChange={(e) => {
                                  setNewQty(e.target.value);
                                  setError(null);
                                }}
                                autoFocus
                              />
                              {Number(newQty) > 0 && (
                                <motion.div 
                                  initial={{ opacity: 0, y: -10 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  className="flex justify-between items-center px-1"
                                >
                                  <div className="flex items-center gap-1.5">
                                    <span className="text-[10px] font-bold uppercase tracking-tight text-slate-400">Remaining Balance:</span>
                                    <span className={`text-[10px] font-black ${Number(currentPO?.['Diff']) - Number(newQty) < 0 ? 'text-rose-500' : 'text-brand-600'}`}>
                                      {Number(currentPO?.['Diff']) - Number(newQty)}
                                    </span>
                                  </div>
                                  {Number(newQty) > Number(currentPO?.['Diff']) && (
                                    <div className="flex items-center gap-1 text-[10px] font-bold text-rose-500 uppercase tracking-tighter animate-pulse">
                                      <AlertCircle className="w-3 h-3" />
                                      <span>Exceeds Balance</span>
                                    </div>
                                  )}
                                </motion.div>
                              )}
                            </div>

                            {error && (
                              <motion.div 
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                                className="p-3 bg-rose-50 border border-rose-100 text-rose-700 rounded-lg text-sm flex items-start gap-2"
                              >
                                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                                <span>{error}</span>
                              </motion.div>
                            )}

                            <button 
                              type="submit"
                              disabled={isSaving}
                              className="w-full bg-brand-600 text-white py-4 rounded-2xl font-display font-bold shadow-xl shadow-brand-200 hover:bg-brand-700 transition-all active:scale-[0.98] disabled:bg-slate-300 disabled:shadow-none flex items-center justify-center gap-2"
                            >
                              {isSaving ? (
                                <>
                                  <RefreshCw className="w-5 h-5 animate-spin" />
                                  <span>Saving to Sheets...</span>
                                </>
                              ) : (
                                <>
                                  <CheckCircle2 className="w-5 h-5" />
                                  <span>Confirm Inward Entry</span>
                                </>
                              )}
                            </button>
                          </form>
                        </div>
                      </Card>
                    </div>
                  )}
                </div>
              )}
            </motion.div>
          ) : activeTab === 'logs' ? (
            <motion.div 
              key="logs"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="space-y-4"
            >
              <div className="space-y-1 mb-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="font-display font-bold text-2xl tracking-tight text-slate-800">Inward Logs</h2>
                    <p className="text-sm text-slate-400 font-medium">History of all material receipts.</p>
                  </div>
                  {(!logHeaders.some(h => h.toLowerCase().replace(/[^a-z0-9]/g, '') === 'userid') || 
                    !logHeaders.some(h => h.toLowerCase().replace(/[^a-z0-9]/g, '') === 'transactionid')) && (
                    <div className="bg-amber-50 border border-amber-100 rounded-xl p-3 flex items-center gap-3 max-w-xs">
                      <AlertCircle className="w-5 h-5 text-amber-500 shrink-0" />
                      <p className="text-[10px] text-amber-700 font-bold leading-tight uppercase tracking-tighter">
                        Missing Headers: Add 
                        {!logHeaders.some(h => h.toLowerCase().replace(/[^a-z0-9]/g, '') === 'userid') && ' "User ID"'}
                        {!logHeaders.some(h => h.toLowerCase().replace(/[^a-z0-9]/g, '') === 'userid') && !logHeaders.some(h => h.toLowerCase().replace(/[^a-z0-9]/g, '') === 'transactionid') && ' &'}
                        {!logHeaders.some(h => h.toLowerCase().replace(/[^a-z0-9]/g, '') === 'transactionid') && ' "transaction_id"'}
                        {" "}columns to "Inward_Logs" sheet.
                      </p>
                    </div>
                  )}
                </div>
              </div>

              <div className="relative group mb-4">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 group-focus-within:text-brand-500 transition-colors" />
                <input 
                  type="text"
                  placeholder="Search Logs by PO, RM, Plant..."
                  className="premium-input pl-12"
                  value={logSearchQuery}
                  onChange={(e) => setLogSearchQuery(e.target.value)}
                />
              </div>

              <motion.div 
                variants={containerVariants}
                initial="hidden"
                animate="show"
                className="space-y-3"
              >
                {filteredLogs.length > 0 ? (
                  filteredLogs.map((log, idx) => {
                    const po = pos.find(p => p[idHeader] === log[idHeader]);
                    const logKey = `${log['Time stamp']}-${log['Bidso PO No']}-${log['RM Code']}-${idx}`;
                    return (
                      <motion.div key={logKey} variants={itemVariants}>
                        <Card className="p-5 border-l-4 border-l-brand-500 hover:shadow-lg active:shadow-xl active:bg-slate-50/50 hover:shadow-brand-900/5 active:shadow-brand-900/10 transition-all active:scale-[0.98]">
                          <div className="grid grid-cols-[1fr_auto] gap-4 items-start pb-2">
                            <div className="space-y-1.5 min-w-0">
                              <h4 className="font-display font-bold text-slate-800 text-[14px] leading-tight break-words">
                                {log['RM Name'] || po?.['RM Name'] || 'Unknown Item'}
                              </h4>
                              <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest break-all">
                                {log['Bidso PO No']} || {log['RM Code']}
                              </p>
                            </div>
                            <div className="text-right shrink-0 space-y-2">
                              <div className="flex flex-col items-end min-w-[70px]">
                                <p className="text-lg font-black text-brand-600">+{log['New Received Quantity']}</p>
                                <p className="text-[9px] text-slate-400 uppercase font-black tracking-tighter opacity-80">{formatDate(String(log['Entry Date']))}</p>
                              </div>
                              <div className="flex justify-end">
                                {log._isLocal ? (
                                  <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-50 text-amber-600 border border-amber-100 text-[8px] font-black uppercase tracking-widest animate-pulse">
                                    <CloudOff className="w-2.5 h-2.5" />
                                    <span>Pending Sync</span>
                                  </div>
                                ) : (
                                  <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-100 text-[8px] font-black uppercase tracking-widest">
                                    <Cloud className="w-2.5 h-2.5" />
                                    <span>Synced</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                          <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-[11px] text-slate-500 font-medium">
                            <div className="flex items-center gap-1.5">
                              <Factory className="w-3.5 h-3.5 text-slate-400" />
                              <span>{log['Plant Name'] || po?.['Plant Name']}</span>
                            </div>
                            <div className="flex items-center gap-1.5">
                              <User className="w-3.5 h-3.5 text-slate-400" />
                              <span className="font-medium">
                                {log['User ID'] || log['User Email'] || log['Email'] || log['Created By'] || 'Unknown User'}
                              </span>
                            </div>
                            {(log['Inv UOM'] || log['Conversion Factor']) && (
                              <div className="flex items-center gap-1.5">
                                <Weight className="w-3.5 h-3.5 text-slate-400" />
                                <span className="font-bold flex items-center gap-1">
                                  {log['Inv UOM']}
                                  {log['Conversion Factor'] && (
                                    <span className="text-[9px] text-slate-400 font-normal">(@ {log['Conversion Factor']} PCs/KG)</span>
                                  )}
                                </span>
                              </div>
                            )}
                            {(log['transaction_id'] || log['Transaction ID']) && (
                              <div className="flex items-center gap-1.5">
                                <Tag className="w-3.5 h-3.5 text-slate-400" />
                                <span className="text-[9px] text-slate-500 font-mono tracking-tighter bg-slate-100/50 px-1.5 py-0.5 rounded border border-slate-200/50">
                                  {log['transaction_id'] || log['Transaction ID']}
                                </span>
                              </div>
                            )}
                          </div>
                        </Card>
                      </motion.div>
                    );
                  })
                ) : (
                  <motion.div variants={itemVariants} className="text-center py-12 text-slate-400 bg-white rounded-3xl border border-dashed border-slate-200">
                    <List className="w-12 h-12 mx-auto mb-3 opacity-20" />
                    <p>{logSearchQuery ? 'No logs match your search.' : 'No inward logs recorded yet.'}</p>
                  </motion.div>
                )}
              </motion.div>
            </motion.div>
          ) : (
            <motion.div 
              key="analysis"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="space-y-6"
            >
              <div className="flex flex-col gap-6">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <h2 className="font-display font-bold text-3xl tracking-tight text-slate-900">PO Analysis</h2>
                    <p className="text-sm text-slate-500 font-medium">Performance metrics and status distribution.</p>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 bg-slate-100/50 p-1.5 rounded-2xl border border-slate-200/60 backdrop-blur-sm w-full md:w-auto">
                    <div className="flex-1 flex items-center gap-3 px-4 py-2 bg-white rounded-xl shadow-sm border border-slate-200/50 relative group min-w-0">
                      <Filter className="w-3.5 h-3.5 text-brand-500 shrink-0" />
                      <select 
                        className="flex-1 bg-transparent text-[11px] font-black uppercase tracking-wider outline-none cursor-pointer text-slate-700 appearance-none pr-10"
                        value={selectedAnalysisPlant}
                        onChange={(e) => setSelectedAnalysisPlant(e.target.value)}
                      >
                        <option value="All">All Plants</option>
                        {plants.map(plant => (
                          <option key={plant} value={plant}>{plant}</option>
                        ))}
                      </select>
                      <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-3 pointer-events-none group-hover:text-brand-500 transition-colors" />
                    </div>
                    <div className="sm:w-36 flex items-center gap-3 px-4 py-2 bg-white rounded-xl shadow-sm border border-slate-200/50 relative group shrink-0">
                      <Calendar className="w-3.5 h-3.5 text-brand-500 shrink-0" />
                      <select 
                        className="flex-1 bg-transparent text-[11px] font-black uppercase tracking-wider outline-none cursor-pointer text-slate-700 appearance-none pr-10"
                        value={selectedYear}
                        onChange={(e) => setSelectedYear(e.target.value)}
                      >
                        {availableYears.map(year => (
                          <option key={year} value={year}>{year === 'All' ? 'All Years' : year}</option>
                        ))}
                      </select>
                      <ChevronDown className="w-3.5 h-3.5 text-slate-400 absolute right-3 pointer-events-none group-hover:text-brand-500 transition-colors" />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-6">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">PO Status Distribution</p>
                    </div>
                    <Card className="p-8 h-[400px] w-full border-none shadow-2xl shadow-slate-200/40 bg-white/80 backdrop-blur-md relative overflow-hidden">
                      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-500 via-emerald-500 to-amber-500 opacity-50" />
                      
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={analysisData}
                          layout="vertical"
                          margin={{ top: 20, right: 30, left: 10, bottom: 0 }}
                        >
                          <defs>
                            <linearGradient id="colorPending" x1="0" y1="0" x2="1" y2="0">
                              <stop offset="5%" stopColor="#94a3b8" stopOpacity={0.8}/>
                              <stop offset="95%" stopColor="#cbd5e1" stopOpacity={0.3}/>
                            </linearGradient>
                            <linearGradient id="colorPartial" x1="0" y1="0" x2="1" y2="0">
                              <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.8}/>
                              <stop offset="95%" stopColor="#fbbf24" stopOpacity={0.3}/>
                            </linearGradient>
                            <linearGradient id="colorCompleted" x1="0" y1="0" x2="1" y2="0">
                              <stop offset="5%" stopColor="#10b981" stopOpacity={0.8}/>
                              <stop offset="95%" stopColor="#34d399" stopOpacity={0.3}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="4 4" horizontal={false} vertical={true} stroke="#f1f5f9" />
                          <XAxis 
                            type="number"
                            axisLine={false} 
                            tickLine={false} 
                            tick={{ fontSize: 10, fontWeight: 700, fill: '#94a3b8' }}
                            hide
                          />
                          <YAxis 
                            dataKey="name"
                            type="category"
                            axisLine={false} 
                            tickLine={false} 
                            tick={{ fontSize: 10, fontWeight: 800, fill: '#64748b' }}
                            style={{ textTransform: 'uppercase' }}
                            width={40}
                          />
                          <Tooltip 
                            cursor={{ fill: '#f8fafc', opacity: 0.4 }}
                            content={({ active, payload, label }) => {
                              if (active && payload && payload.length) {
                                const total = payload.reduce((sum, entry) => sum + (entry.value as number), 0);
                                return (
                                  <div className="bg-white/90 backdrop-blur-xl p-4 rounded-2xl shadow-2xl border border-slate-100 min-w-[160px]">
                                    <div className="flex justify-between items-center mb-3 border-b border-slate-100 pb-2">
                                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{label}</p>
                                      <p className="text-[10px] font-black text-brand-600 bg-brand-50 px-1.5 py-0.5 rounded">Total: {total}</p>
                                    </div>
                                    <div className="space-y-2">
                                      {payload.map((entry: any) => (
                                        <div key={entry.name} className="flex justify-between items-center gap-4">
                                          <div className="flex items-center gap-2">
                                            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: entry.color }} />
                                            <span className="text-xs font-bold text-slate-600">{entry.name}</span>
                                          </div>
                                          <span className="text-xs font-black text-slate-900">{entry.value}</span>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                );
                              }
                              return null;
                            }}
                          />
                          <Legend 
                            verticalAlign="top" 
                            align="center" 
                            iconType="circle"
                            iconSize={6}
                            wrapperStyle={{ 
                              paddingBottom: '40px', 
                              fontSize: '8px', 
                              fontWeight: 900, 
                              textTransform: 'uppercase', 
                              letterSpacing: '0.02em', 
                              color: '#64748b',
                              width: '100%',
                              display: 'flex',
                              justifyContent: 'center',
                              gap: '8px',
                              whiteSpace: 'nowrap'
                            }}
                          />
                          <Bar dataKey="Pending" stackId="a" fill="url(#colorPending)" barSize={20} />
                          <Bar dataKey="Partial" stackId="a" fill="url(#colorPartial)" barSize={20} />
                          <Bar dataKey="Completed" stackId="a" fill="url(#colorCompleted)" radius={[0, 4, 4, 0]} barSize={20} />
                        </BarChart>
                      </ResponsiveContainer>
                    </Card>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Quantity Trend: Ordered vs Received</p>
                    </div>
                    <Card className="p-8 h-[400px] w-full border-none shadow-2xl shadow-slate-200/40 bg-white/80 backdrop-blur-md relative overflow-hidden">
                      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-brand-600 to-emerald-500 opacity-50" />
                      
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart
                          data={quantityTrendData}
                          margin={{ top: 20, right: 30, left: 10, bottom: 0 }}
                        >
                          <CartesianGrid strokeDasharray="4 4" vertical={false} stroke="#f1f5f9" />
                          <XAxis 
                            dataKey="name" 
                            axisLine={false} 
                            tickLine={false} 
                            tick={{ fontSize: 10, fontWeight: 800, fill: '#64748b' }}
                            style={{ textTransform: 'uppercase' }}
                          />
                          <YAxis 
                            axisLine={false} 
                            tickLine={false} 
                            tick={{ fontSize: 10, fontWeight: 700, fill: '#94a3b8' }}
                          />
                          <Tooltip 
                            content={({ active, payload, label }) => {
                              if (active && payload && payload.length) {
                                return (
                                  <div className="bg-white/90 backdrop-blur-xl p-4 rounded-2xl shadow-2xl border border-slate-100 min-w-[160px]">
                                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 border-b border-slate-100 pb-2">{label}</p>
                                    <div className="space-y-2">
                                      {payload.map((entry: any) => (
                                        <div key={entry.name} className="flex justify-between items-center gap-4">
                                          <div className="flex items-center gap-2">
                                            <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: entry.color }} />
                                            <span className="text-xs font-bold text-slate-600">{entry.name}</span>
                                          </div>
                                          <span className="text-xs font-black text-slate-900">{entry.value.toLocaleString()}</span>
                                        </div>
                                      ))}
                                    </div>
                                  </div>
                                );
                              }
                              return null;
                            }}
                          />
                          <Legend 
                            verticalAlign="top" 
                            align="center" 
                            iconType="circle"
                            iconSize={6}
                            wrapperStyle={{ 
                              paddingBottom: '40px', 
                              fontSize: '8px', 
                              fontWeight: 900, 
                              textTransform: 'uppercase', 
                              letterSpacing: '0.02em', 
                              color: '#64748b'
                            }}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="Ordered" 
                            stroke="#4f46e5" 
                            strokeWidth={3} 
                            dot={{ fill: '#4f46e5', strokeWidth: 2, r: 4, stroke: '#fff' }}
                            activeDot={{ r: 6, strokeWidth: 0 }}
                          />
                          <Line 
                            type="monotone" 
                            dataKey="Received" 
                            stroke="#10b981" 
                            strokeWidth={3} 
                            dot={{ fill: '#10b981', strokeWidth: 2, r: 4, stroke: '#fff' }}
                            activeDot={{ r: 6, strokeWidth: 0 }}
                          />
                        </LineChart>
                      </ResponsiveContainer>
                    </Card>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Lead Time Analysis (Avg Days by Material)</p>
                    </div>
                    <Card className="p-8 h-[400px] w-full border-none shadow-2xl shadow-slate-200/40 bg-white/80 backdrop-blur-md relative overflow-hidden">
                      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 to-purple-500 opacity-50" />
                      
                      {leadTimeAnalysis.byVendor.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={leadTimeAnalysis.byVendor.slice(0, 10)}
                            layout="vertical"
                            margin={{ top: 20, right: 30, left: 10, bottom: 0 }}
                          >
                            <CartesianGrid strokeDasharray="4 4" horizontal={false} vertical={true} stroke="#f1f5f9" />
                            <XAxis 
                              type="number"
                              axisLine={false} 
                              tickLine={false} 
                              tick={{ fontSize: 10, fontWeight: 700, fill: '#94a3b8' }}
                            />
                            <YAxis 
                              dataKey="key"
                              type="category"
                              axisLine={false} 
                              tickLine={false} 
                              tick={{ fontSize: 9, fontWeight: 800, fill: '#64748b' }}
                              style={{ textTransform: 'uppercase' }}
                              width={150}
                              tickFormatter={(val) => val.split(' || ')[0]} // Show just the RM Name on axis
                            />
                            <Tooltip 
                               cursor={{ fill: '#f8fafc', opacity: 0.4 }}
                               content={({ active, payload, label }) => {
                                 if (active && payload && payload.length) {
                                   const data = payload[0].payload;
                                   return (
                                     <div className="bg-white/90 backdrop-blur-xl p-4 rounded-2xl shadow-2xl border border-slate-100 min-w-[180px]">
                                       <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 border-b border-slate-100 pb-2">{data.rmName}</p>
                                       <p className="text-[9px] font-bold text-slate-500 uppercase mb-3 truncate max-w-[200px]">Vendor: {data.vendor}</p>
                                       <div className="space-y-2">
                                         <div className="flex justify-between items-center">
                                           <span className="text-xs font-bold text-slate-600">Avg Lead Time:</span>
                                           <span className="text-xs font-black text-brand-600">{data.avgDays} Days</span>
                                         </div>
                                         <div className="flex justify-between items-center text-[10px]">
                                           <span className="text-slate-400">Min/Max:</span>
                                           <span className="font-bold text-slate-500">{data.minDays} - {data.maxDays} Days</span>
                                         </div>
                                         <div className="flex justify-between items-center text-[10px]">
                                           <span className="text-slate-400">Sample Size:</span>
                                           <span className="font-bold text-slate-500">{data.count} Orders</span>
                                         </div>
                                       </div>
                                     </div>
                                   );
                                 }
                                 return null;
                               }}
                            />
                            <Bar dataKey="avgDays" fill="#6366f1" radius={[0, 4, 4, 0]} barSize={20}>
                              {leadTimeAnalysis.byVendor.slice(0, 10).map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#6366f1' : '#818cf8'} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      ) : (
                        <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-4">
                           <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center">
                             <Clock className="w-8 h-8 text-slate-300" />
                           </div>
                           <div className="space-y-1">
                             <p className="font-display font-bold text-slate-800">No Lead Time Data</p>
                             <p className="text-xs text-slate-400 max-w-[200px]">At least one completed or partial PO with inward logs is required.</p>
                           </div>
                        </div>
                      )}
                    </Card>
                  </div>
                </div>

                <motion.div 
                  variants={containerVariants}
                  initial="hidden"
                  animate="show"
                  className="grid grid-cols-2 sm:grid-cols-4 gap-4"
                >
                  {['Pending', 'Partial', 'Completed', 'RunningDelay'].map((status, idx) => {
                    const total = analysisData.reduce((sum, d) => sum + (d[status as keyof typeof d] as number), 0);
                    
                    let color = 'text-slate-500';
                    let bg = 'bg-slate-50/50';
                    let icon = <Lock className="w-5 h-5" />;
                    let label = status;

                    if (status === 'Completed') {
                      color = 'text-emerald-600';
                      bg = 'bg-emerald-50/50';
                      icon = <ShieldCheck className="w-5 h-5" />;
                    } else if (status === 'Partial') {
                      color = 'text-amber-600';
                      bg = 'bg-amber-50/50';
                      icon = <RefreshCw className="w-5 h-5" />;
                    } else if (status === 'RunningDelay') {
                      color = 'text-rose-600';
                      bg = 'bg-rose-50/50';
                      icon = <ShieldAlert className="w-5 h-5" />;
                      label = 'Running Delay';
                    }
                    
                    return (
                      <motion.div key={status} variants={itemVariants}>
                        <div className={`${bg} p-4 sm:p-6 rounded-[2rem] border border-white shadow-sm relative overflow-hidden group hover:shadow-md transition-all h-full flex flex-col justify-between`}>
                          <div className={`absolute -right-4 -top-4 w-20 h-20 ${color} opacity-[0.03] rotate-12 group-hover:scale-110 transition-transform`}>
                            {icon}
                          </div>
                          <div>
                            <div className="flex items-center gap-2 mb-3">
                              <div className={`p-1.5 rounded-lg ${
                                status === 'Completed' ? 'bg-emerald-100 text-emerald-600' : 
                                status === 'Partial' ? 'bg-amber-100 text-amber-600' : 
                                status === 'RunningDelay' ? 'bg-rose-100 text-rose-600' :
                                'bg-slate-200 text-slate-500'
                              }`}>
                                {React.cloneElement(icon as React.ReactElement<any>, { className: 'w-3.5 h-3.5' })}
                              </div>
                              <p className="text-[9px] font-black uppercase text-slate-400 tracking-widest truncate">{label}</p>
                            </div>
                            <div className="flex items-baseline gap-1.5">
                              <p className={`text-2xl sm:text-4xl font-display font-bold ${color}`}>{total}</p>
                              <p className="text-[10px] font-bold text-slate-400">POs</p>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </motion.div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Reset Confirmation Modal */}
      <AnimatePresence>
        {showResetConfirm && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowResetConfirm(false)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-sm bg-white rounded-3xl p-8 shadow-2xl space-y-6"
            >
              <div className="w-16 h-16 bg-amber-100 rounded-2xl flex items-center justify-center mx-auto">
                <Trash2 className="text-amber-600 w-8 h-8" />
              </div>
              <div className="text-center space-y-2">
                <h3 className="text-xl font-black text-slate-800">Clear Local Memory?</h3>
                <p className="text-sm text-slate-500 leading-relaxed">
                  This will remove all <b>Pending Sync</b> logs and log you out. This action cannot be undone.
                </p>
              </div>
              <div className="flex gap-3">
                <button 
                  onClick={() => setShowResetConfirm(false)}
                  className="flex-1 px-4 py-3.5 border border-slate-200 rounded-2xl text-slate-500 font-bold hover:bg-slate-50 transition-all active:scale-95"
                >
                  Cancel
                </button>
                <button 
                  onClick={confirmReset}
                  className="flex-1 px-4 py-3.5 bg-rose-600 text-white font-bold rounded-2xl hover:bg-rose-700 shadow-lg shadow-rose-200 transition-all active:scale-95"
                >
                  Clear All
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Inward History Modal */}
      <AnimatePresence>
        {selectedHistoryPO && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 sm:p-12 overflow-hidden">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedHistoryPO(null)}
              className="absolute inset-0 bg-slate-900/70 backdrop-blur-md"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 30 }}
              className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden"
            >
              {/* Header */}
              <div className="p-6 sm:p-8 bg-slate-50 border-b border-slate-100 flex justify-between items-start">
                <div className="min-w-0">
                  <h2 className="font-display font-bold text-2xl text-slate-800 truncate mb-1" title={selectedHistoryPO[idHeader]}>
                    {selectedHistoryPO[idHeader]}
                  </h2>
                  <p className="text-[12px] text-slate-500 font-bold leading-tight whitespace-normal break-words mt-1">
                    {selectedHistoryPO['RM Name']}
                  </p>
                </div>
                <button 
                  onClick={() => setSelectedHistoryPO(null)}
                  className="p-2.5 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-brand-600 transition-all active:scale-90 shadow-sm"
                >
                  <ArrowLeft className="w-5 h-5" />
                </button>
              </div>

              {/* Body */}
              <div className="flex-1 overflow-y-auto custom-scrollbar p-6 sm:p-8 space-y-8">
                {/* Stats Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="p-4 bg-slate-50 rounded-2xl space-y-1">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-tight">Order Qty</p>
                    <p className="text-lg font-bold text-slate-700">{selectedHistoryPO['Order Quantity']}</p>
                  </div>
                  <div className="p-4 bg-emerald-50 rounded-2xl space-y-1">
                    <p className="text-[10px] font-black text-emerald-400 uppercase tracking-tight">Received</p>
                    <p className="text-lg font-bold text-emerald-600">{selectedHistoryPO['Received QTY']}</p>
                  </div>
                  <div className="p-4 bg-amber-50 rounded-2xl space-y-1">
                    <p className="text-[10px] font-black text-amber-400 uppercase tracking-tight">Pending</p>
                    <p className="text-lg font-bold text-amber-600">{selectedHistoryPO['Diff']}</p>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-2xl space-y-1">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-tight">Vendor</p>
                    <p className="text-[13px] font-bold text-slate-700 truncate" title={selectedHistoryPO['Vendor']}>
                      {selectedHistoryPO['Vendor']}
                    </p>
                  </div>
                </div>

                {/* Log List */}
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-brand-50 text-brand-600 rounded-lg">
                      <List className="w-4 h-4" />
                    </div>
                    <h3 className="font-display font-bold text-lg text-slate-800">Inward Receipt Logs</h3>
                  </div>

                  <div className="space-y-3 relative before:absolute before:left-5 before:top-4 before:bottom-4 before:w-px before:bg-slate-100">
                    {poLogs.length > 0 ? (
                      poLogs.map((log, index) => (
                        <div key={index} className="relative pl-12">
                          <div className="absolute left-3.5 top-1.5 w-3.5 h-3.5 rounded-full bg-white border-2 border-brand-500 z-10" />
                          <div className="bg-white border border-slate-100 rounded-2xl p-4 shadow-sm hover:shadow-md hover:border-brand-100 transition-all group">
                            <div className="flex justify-between items-start mb-2 gap-4">
                              <div className="flex items-center gap-2">
                                <p className="text-[16px] font-black text-slate-800">+{log['New Received Quantity']}</p>
                                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">PCs</span>
                              </div>
                              <div className="flex items-center gap-1.5 text-emerald-500 bg-emerald-50 px-2 py-0.5 rounded-full">
                                <CheckCircle2 className="w-3 h-3" />
                                <span className="text-[9px] font-black uppercase tracking-widest">Verified</span>
                              </div>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4 text-[11px]">
                              <div className="flex items-center gap-2 text-slate-500">
                                <Calendar className="w-3.5 h-3.5 text-slate-300" />
                                <span className="font-medium">{formatDate(log['Entry Date'] || log['Time stamp'])}</span>
                              </div>
                              <div className="flex items-center gap-2 text-slate-500 justify-end">
                                <User className="w-3.5 h-3.5 text-slate-300" />
                                <span className="font-medium truncate max-w-[120px]">{log['User ID'] || 'System Administrator'}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-12 p-8 bg-slate-50 rounded-3xl border border-dashed border-slate-200">
                        <Clock className="w-10 h-10 text-slate-300 mx-auto mb-3 opacity-50" />
                        <p className="text-sm font-medium text-slate-400">No inward logs found for this PO.</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="p-6 sm:p-8 bg-slate-50/50 border-t border-slate-100 flex gap-3">
                <button 
                  onClick={() => setSelectedHistoryPO(null)}
                  className="flex-1 px-6 py-4 border border-slate-200 bg-white rounded-2xl font-bold text-slate-500 hover:bg-slate-100 transition-all active:scale-[0.98]"
                >
                  Close
                </button>
                <button 
                  onClick={() => {
                    const po = selectedHistoryPO;
                    setSelectedBidsoPO(po['Bidso PO no'] || po[idHeader]);
                    setSelectedPlant(po['Plant Name']);
                    setSelectedRMCode(po['RM Code']);
                    setWorkflowStep(2);
                    setActiveTab('inward');
                    setSelectedHistoryPO(null);
                  }}
                  className={`flex-[2] px-6 py-4 bg-brand-600 text-white rounded-2xl font-display font-bold shadow-xl shadow-brand-100 hover:bg-brand-700 transition-all active:scale-[0.98] flex items-center justify-center gap-2 ${Number(selectedHistoryPO['Received QTY']) >= Number(selectedHistoryPO['Order Quantity']) ? 'opacity-50 pointer-events-none' : ''}`}
                >
                  <PlusCircle className="w-5 h-5" />
                  <span>Log New Inward</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <TabBar 
        activeTab={activeTab} 
        onTabChange={(tab) => {
          setActiveTab(tab);
          if (tab === 'history') resetWorkflow();
        }} 
        tabs={mainTabs} 
      />
    </motion.div>
    </ErrorBoundary>
  );
}

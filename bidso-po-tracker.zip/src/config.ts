/**
 * Application Configuration & Feature Flags
 * 
 * Professionals use this to manage differences between Development and Production.
 */

// Tracking current build version (SemVer)
export const APP_VERSION = '1.0.1';

// Determine environment
// In Vite, import.meta.env.MODE is 'development' locally and 'production' when built
export const IS_DEV = import.meta.env.DEV;

export interface FeatureFlags {
  enableNewAnalytics: boolean;
  enableBetaGestures: boolean;
  maintenanceMode: boolean;
}

export interface FeatureMetadata {
  id: keyof FeatureFlags;
  label: string;
  description: string;
  status: 'In Progress' | 'Beta Testing' | 'Ready for Production';
}

/**
 * Feature Toggles
 * Set to 'true' in development to test, but keep 'false' until ready for production.
 */
export const FEATURES: FeatureFlags = {
  enableNewAnalytics: true, 
  enableBetaGestures: true,
  maintenanceMode: false,
};

/**
 * Feature Inventory
 * This helps you track what you are working on.
 */
export const FEATURE_INVENTORY: FeatureMetadata[] = [
  {
    id: 'enableBetaGestures',
    label: 'Fluid Swipe Navigation',
    description: 'Enables mobile swiping between history, inward, logs, and analysis.',
    status: 'Ready for Production'
  },
  {
    id: 'enableNewAnalytics',
    label: 'Advanced PO Analytics',
    description: 'Deep-dive charts and trends for PO fulfillment tracking.',
    status: 'Ready for Production'
  },
  {
    id: 'maintenanceMode',
    label: 'Emergency Kill-Switch',
    description: 'Locks the application for users during critical database updates.',
    status: 'In Progress'
  }
];

export const CONFIG = {
  version: APP_VERSION,
  env: IS_DEV ? 'Development' : 'Production',
  isDev: IS_DEV,
  features: FEATURES,
  inventory: FEATURE_INVENTORY,
};

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, BookOpen, Terminal, ChevronRight, CheckCircle2, CircleDashed, Rocket, FlaskConical, AlertCircle, Power, Info, ArrowLeft } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';

import logicDocs from '../../LOGIC_DOCUMENTATION.md?raw';
import { CONFIG } from '../config';
import { useFeatures } from '../context/FeatureContext';

interface AppMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AppMenu: React.FC<AppMenuProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'main' | 'docs' | 'devtools'>('main');
  
  React.useEffect(() => {
    if (!isOpen) {
      setTimeout(() => setActiveTab('main'), 300);
    }
  }, [isOpen]);

  // DevTools State
  const { toggleFeature, getFeature } = useFeatures();
  const [releaseInfo, setReleaseInfo] = useState<{id: string, label: string} | null>(null);

  const clearOverrides = () => {
    CONFIG.inventory.forEach(f => localStorage.removeItem(`FEATURE_OVERRIDE_${f.id}`));
    window.location.href = window.location.pathname + window.location.search;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Ready for Production': return <Rocket className="w-3.5 h-3.5" />;
      case 'Beta Testing': return <FlaskConical className="w-3.5 h-3.5" />;
      default: return <CircleDashed className="w-3.5 h-3.5" />;
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[9998]"
          />

          <motion.div
            initial={{ x: -400 }}
            animate={{ x: 0 }}
            exit={{ x: -400 }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-y-0 left-0 w-full max-w-sm bg-white shadow-2xl z-[9999] flex flex-col border-r border-slate-200"
          >
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50 shrink-0">
              <div className="flex items-center gap-3">
                {activeTab !== 'main' ? (
                  <button 
                    onClick={() => setActiveTab('main')}
                    className="p-2 -ml-2 mr-1 hover:bg-slate-200 rounded-xl transition-colors text-slate-500 hover:text-slate-700 active:scale-95 flex items-center justify-center shrink-0"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </button>
                ) : (
                  <div className="bg-brand-100 p-2 rounded-lg text-brand-600">
                    <BookOpen className="w-5 h-5" />
                  </div>
                )}
                <div>
                  <h2 className="font-bold text-lg leading-tight truncate">
                    {activeTab === 'main' ? 'App Menu' : activeTab === 'docs' ? 'Documentation' : 'Dev Console'}
                  </h2>
                  <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                    v{CONFIG.version}
                  </div>
                </div>
              </div>
              <button 
                onClick={onClose}
                className="p-2 hover:bg-slate-200 rounded-xl transition-colors text-slate-400 hover:text-slate-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto bg-slate-50/50">
              <AnimatePresence mode="wait">
              {activeTab === 'main' && (
                <motion.div 
                  key="main"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="p-4 grid grid-cols-2 gap-3"
                >
                  <button
                    onClick={() => setActiveTab('docs')}
                    className="w-full flex flex-col items-center justify-center p-5 bg-white border border-slate-200 rounded-xl shadow-sm hover:shadow-md hover:border-slate-300 transition-all active:scale-[0.98] group text-center"
                  >
                    <div className="w-12 h-12 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:scale-110 group-hover:bg-indigo-100 transition-all mb-3">
                      <BookOpen className="w-5 h-5" />
                    </div>
                    <h3 className="font-bold text-slate-800 text-sm leading-tight">Documentation</h3>
                    <p className="text-[10px] text-slate-500 mt-1 leading-snug">Read app logic & guidelines</p>
                  </button>
                  
                  {CONFIG.isDev && (
                    <button
                      onClick={() => setActiveTab('devtools')}
                      className="w-full flex flex-col items-center justify-center p-5 bg-white border border-slate-200 rounded-xl shadow-sm hover:shadow-md hover:border-slate-300 transition-all active:scale-[0.98] group text-center"
                    >
                      <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center group-hover:scale-110 group-hover:bg-slate-200 transition-all mb-3">
                        <Terminal className="w-5 h-5" />
                      </div>
                      <h3 className="font-bold text-slate-800 text-sm leading-tight">Dev Console</h3>
                      <p className="text-[10px] text-slate-500 mt-1 leading-snug">Feature flags & overrides</p>
                    </button>
                  )}
                </motion.div>
              )}

              {activeTab === 'docs' && (
                <motion.div 
                  key="docs"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="p-6"
                >
                  <div className="prose prose-sm prose-slate max-w-none 
                    prose-h1:text-xl prose-h1:font-black prose-h1:mb-4
                    prose-h2:text-sm prose-h2:font-bold prose-h2:uppercase prose-h2:tracking-widest prose-h2:text-slate-400 prose-h2:mt-8 prose-h2:mb-3
                    prose-h3:text-sm prose-h3:font-bold prose-h3:text-slate-800 prose-h3:mt-6
                    prose-p:text-slate-600 prose-p:leading-relaxed prose-p:text-[13px]
                    prose-li:text-[13px] prose-li:text-slate-600
                    prose-strong:text-slate-900 prose-strong:font-bold
                    prose-ul:mt-2 prose-ul:mb-4
                    prose-code:text-xs prose-code:bg-slate-100 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded prose-code:text-indigo-600
                    prose-hr:my-6 prose-hr:border-slate-200">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>
                      {logicDocs}
                    </ReactMarkdown>
                  </div>
                </motion.div>
              )}

              {activeTab === 'devtools' && CONFIG.isDev && (
                <motion.div 
                  key="devtools"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="p-5 space-y-6"
                >
                  <AnimatePresence mode="wait">
                    {releaseInfo ? (
                      <motion.div 
                        key="release-guide"
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        className="space-y-4"
                      >
                        <button 
                          onClick={() => setReleaseInfo(null)}
                          className="flex items-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider hover:text-slate-600 transition-colors"
                        >
                          <ArrowLeft className="w-3 h-3" /> Back
                        </button>
                        <div className="p-5 bg-emerald-50 border border-emerald-100 rounded-2xl space-y-4">
                          <div className="flex items-center gap-3">
                            <Rocket className="w-5 h-5 text-emerald-600" />
                            <h3 className="font-bold text-emerald-900 text-sm">Automated Release</h3>
                          </div>
                          <div className="space-y-3">
                            <p className="text-[11px] text-emerald-800 leading-relaxed font-medium">
                              I am ready to finalize the release for <strong className="text-emerald-900">"{releaseInfo.label}"</strong>. 
                              I will update the version, flip the flags, and set it to <strong className="text-emerald-900">Production</strong>.
                            </p>
                            <div className="bg-white/60 rounded-xl p-3 border border-emerald-100/50">
                              <p className="text-[9px] font-bold text-emerald-600 uppercase tracking-widest mb-1">Copy & Send to AI Agent:</p>
                              <p className="text-[11px] text-emerald-900 font-mono break-all leading-tight font-bold">
                                Deploy feature {releaseInfo.id} to production tracking branch
                              </p>
                            </div>
                            <button 
                              onClick={() => {
                                const cmd = `Deploy feature ${releaseInfo.id} to production tracking branch`;
                                navigator.clipboard.writeText(cmd);
                                alert("Command copied! Just paste it into the chat.");
                              }}
                              className="w-full py-2.5 bg-emerald-600 text-white text-[10px] font-bold uppercase tracking-widest rounded-xl shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all active:scale-95"
                            >
                              Copy Deploy Command
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    ) : (
                      <motion.div 
                        key="feature-list"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 20 }}
                        className="space-y-5"
                      >
                        <div className="flex items-start gap-3 p-4 bg-white border border-slate-200 shadow-sm rounded-xl">
                          <Info className="w-4 h-4 text-indigo-500 mt-0.5 shrink-0" />
                          <div className="space-y-1.5">
                            <p className="text-[10px] text-slate-700 font-bold uppercase tracking-widest">
                              Dev Console Guide
                            </p>
                            <p className="text-xs text-slate-500 leading-relaxed">
                              Use these flags to toggle Work-In-Progress features. These overrides are stored locally on your device.
                            </p>
                            <div className="grid grid-cols-1 gap-2 pt-2 mt-2 border-t border-slate-100">
                              <div className="flex items-center gap-2">
                                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                                <span className="text-[10px] text-slate-600 font-medium tracking-tight">Production (Live)</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <div className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                                <span className="text-[10px] text-slate-600 font-medium tracking-tight">Beta Testing</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="grid gap-3">
                          {CONFIG.inventory.map((feature) => {
                            const isEnabled = getFeature(feature.id);
                            const isOverridden = localStorage.getItem(`FEATURE_OVERRIDE_${feature.id}`) !== null;

                            return (
                              <div key={feature.id} className="p-4 bg-white border border-slate-200 rounded-xl shadow-sm relative overflow-hidden">
                                {isOverridden && (
                                  <div className="absolute top-0 right-0 w-10 h-10 overflow-hidden">
                                    <div className="absolute top-0 right-0 w-14 h-14 bg-amber-100 translate-x-7 -translate-y-7 rotate-45 transform" />
                                  </div>
                                )}
                                
                                <div className="flex items-start justify-between gap-3 relative z-10">
                                  <div className="min-w-0 pr-4">
                                    <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                                      <h3 className="font-bold text-slate-800 text-sm leading-tight group-hover:text-brand-600 transition-colors">{feature.label}</h3>
                                    </div>
                                    <p className="text-xs text-slate-500 leading-snug mb-3">
                                      {feature.description}
                                    </p>
                                    <div className="flex flex-wrap items-center gap-2">
                                      <div className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-wider flex items-center gap-1 w-fit
                                        ${feature.status === 'Ready for Production' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 
                                          feature.status === 'Beta Testing' ? 'bg-amber-50 text-amber-600 border border-amber-100' : 'bg-slate-100 text-slate-500 border border-slate-200'}`}>
                                        {feature.status}
                                      </div>
                                      <span className="text-[9px] text-slate-400 font-mono tracking-tight bg-slate-50 px-1.5 py-0.5 rounded border border-slate-100 uppercase">
                                        {feature.id}
                                      </span>
                                    </div>
                                  </div>
                                  
                                  <div className="flex flex-col items-center gap-2 shrink-0">
                                    <button
                                      onClick={() => toggleFeature(feature.id)}
                                      className={`w-11 h-6 rounded-full p-1 transition-all duration-300 flex items-center shrink-0 ${isEnabled ? 'bg-indigo-600' : 'bg-slate-200'}`}
                                    >
                                      <div className={`w-4 h-4 rounded-full bg-white shadow-sm transition-all duration-300 transform ${isEnabled ? 'translate-x-5' : 'translate-x-0'}`} />
                                    </button>
                                    
                                    {feature.status !== 'Ready for Production' && (
                                      <button
                                        onClick={() => setReleaseInfo({ id: feature.id, label: feature.label })}
                                        className="text-[9px] font-bold text-indigo-600 uppercase tracking-wider hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-2 py-1 rounded transition-colors"
                                      >
                                        Deploy
                                      </button>
                                    )}
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                        
                        <div className="pt-4 border-t border-slate-200">
                          <button 
                            onClick={clearOverrides}
                            className="w-full text-[11px] font-bold text-slate-500 bg-slate-100 hover:bg-slate-200 hover:text-slate-800 uppercase tracking-wider py-3 rounded-xl transition-colors text-center"
                          >
                            Clear Overrides & Reload
                          </button>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              )}
              </AnimatePresence>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

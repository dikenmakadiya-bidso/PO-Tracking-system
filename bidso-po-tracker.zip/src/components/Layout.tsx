import React from 'react';
import { Package, RefreshCw, LogOut, ShieldCheck, Terminal, Menu } from 'lucide-react';
import { CONFIG } from '../config';

interface HeaderProps {
  user: any;
  isSyncing: boolean;
  onSync: () => void;
  onLogout: () => void;
  onMenuClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({ user, isSyncing, onSync, onLogout, onMenuClick }) => (
  <header className="bg-white/80 backdrop-blur-md border-b border-slate-200/60 sticky top-0 z-30 px-4 py-4 sm:py-5" style={{ paddingTop: 'calc(1rem + env(safe-area-inset-top))' }}>
    <div className="max-w-4xl mx-auto flex justify-between items-center">
      <div className="flex items-center gap-2 sm:gap-3">
        <button
          onClick={onMenuClick}
          className="p-2 -ml-2 mr-1 hover:bg-slate-100 rounded-xl transition-colors text-slate-500 active:scale-95 flex items-center justify-center shrink-0"
        >
          <Menu className="w-5 h-5 sm:w-6 sm:h-6" />
        </button>
        <div className="bg-brand-600 p-2 sm:p-2.5 rounded-xl shadow-lg shadow-brand-200 relative group hidden sm:block">
          <Package className="text-white w-5 h-5" />
          <div className="absolute -top-1 -right-1 w-3 h-3 bg-white rounded-full flex items-center justify-center border-2 border-brand-600">
             <div className={`w-1 h-1 rounded-full ${CONFIG.isDev ? 'bg-amber-400' : 'bg-emerald-400'}`} />
          </div>
        </div>
        <div className="bg-brand-600 p-1.5 rounded-lg shadow-sm relative group sm:hidden block">
          <Package className="text-white w-4 h-4" />
        </div>
        <div>
          <div className="flex items-center gap-1.5 sm:gap-2">
            <h1 className="font-display font-bold text-base sm:text-lg leading-tight tracking-tight">Bidso PO Tracker</h1>
            <span className="hidden sm:inline-block text-[9px] px-1.5 py-0.5 bg-slate-100 text-slate-500 rounded font-mono font-bold">v{CONFIG.version}</span>
          </div>
          {user && (
            <div className="flex items-center gap-1.5 text-[9px] sm:text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">
              <ShieldCheck className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-emerald-500" />
              <span className="truncate max-w-[100px] sm:max-w-none">{user.email}</span>
              {CONFIG.isDev && (
                <>
                  <span className="mx-1 opacity-30">•</span>
                  <div className="flex items-center gap-1 text-amber-500/80">
                    <Terminal className="w-2.5 h-2.5" />
                    <span>DEV</span>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>
      <div className="flex items-center gap-1 sm:gap-2">
        <button 
          onClick={onSync}
          disabled={isSyncing}
          className="p-2 sm:p-2.5 hover:bg-slate-100 rounded-xl transition-all text-slate-500 disabled:opacity-50 active:scale-95"
          title="Sync with Google Sheets"
        >
          <RefreshCw className={`w-4 h-4 sm:w-5 sm:h-5 ${isSyncing ? 'animate-spin' : ''}`} />
        </button>
        <button 
          onClick={onLogout}
          className="p-2 sm:p-2.5 hover:bg-rose-50 rounded-xl transition-all text-slate-400 hover:text-rose-600 active:scale-95"
          title="Logout"
        >
          <LogOut className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>
      </div>
    </div>
  </header>
);

export const TabBar: React.FC<{
  activeTab: string;
  onTabChange: (tab: any) => void;
  tabs: { id: string; label: string; icon: React.ReactNode }[];
}> = ({ activeTab, onTabChange, tabs }) => (
  <div className="fixed left-4 right-4 z-40 lg:hidden" style={{ bottom: 'calc(1.5rem + env(safe-area-inset-bottom))' }}>
    <div 
      className="mx-auto bg-white/30 backdrop-blur-3xl flex justify-between items-center shadow-[0_20px_50px_rgba(0,0,0,0.1)] border border-white/40 rounded-[36px] p-1.5" 
      style={{ width: '310px', height: '68px' }}
    >
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`flex-1 flex flex-col items-center justify-center gap-1 h-full transition-all duration-300 rounded-[28px] relative overflow-hidden ${
              isActive ? 'bg-[#0072BC]/15 text-[#0072BC]' : 'text-slate-500/70 hover:text-slate-700'
            }`}
          >
            <div className={`transition-all duration-300 ${isActive ? 'scale-110' : 'scale-100'}`}>
              {React.cloneElement(tab.icon as React.ReactElement<any>, { 
                className: `w-5 h-5 transition-colors ${isActive ? 'text-[#0072BC]' : 'text-slate-400'}` 
              })}
            </div>
            <span className={`text-[10px] font-bold tracking-tight transition-all uppercase ${isActive ? 'font-black' : 'font-medium opacity-80'}`}>
              {tab.label}
            </span>
          </button>
        );
      })}
    </div>
  </div>
);

import React from 'react';

export const Card = ({ children, className = "", key, onClick }: { children: React.ReactNode, className?: string, key?: React.Key, onClick?: () => void }) => (
  <div key={key} onClick={onClick} className={`premium-card overflow-hidden ${className} ${onClick ? 'cursor-pointer' : ''}`}>
    {children}
  </div>
);

export const Badge = ({ children, variant = 'default' }: { children: React.ReactNode, variant?: 'default' | 'success' | 'warning' | 'danger' }) => {
  const variants = {
    default: 'bg-slate-100 text-slate-600 border-slate-200',
    success: 'bg-emerald-50 text-emerald-700 border-emerald-100',
    warning: 'bg-amber-50 text-amber-700 border-amber-100',
    danger: 'bg-rose-50 text-rose-700 border-rose-100',
  };
  return (
    <span className={`px-2.5 py-0.5 rounded-lg text-[10px] font-bold uppercase tracking-wider border ${variants[variant]}`}>
      {children}
    </span>
  );
};

export const parseDate = (dateStr: string): Date | null => {
  if (!dateStr || dateStr === 'undefined' || dateStr === 'null' || dateStr.trim() === '') return null;
  
  let date: Date;
  
  if (dateStr.includes('-')) {
    const parts = dateStr.split('-');
    if (parts[0].length === 4) {
      date = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
    } else {
      date = new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]));
    }
  } 
  else if (dateStr.includes('/')) {
    const parts = dateStr.split('/');
    if (parts[2].length === 4) {
      date = new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]));
    } else {
      date = new Date(dateStr);
    }
  } else {
    date = new Date(dateStr);
  }

  return isNaN(date.getTime()) ? null : date;
};

export const formatDate = (dateStr: string) => {
  const date = parseDate(dateStr);
  if (!date) return dateStr || '';

  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  
  return `${day}-${month}-${year}`;
};

export const isDatePassed = (dateStr: string) => {
  const date = parseDate(dateStr);
  if (!date) return false;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const targetDate = new Date(date);
  targetDate.setHours(0, 0, 0, 0);
  
  return targetDate < today;
};

export const DateDisplay = ({ date, label }: { date: string, label?: string }) => {
  if (!date || date === 'undefined' || date === 'null' || date.trim() === '') {
    return <span className="text-slate-400 italic">{label}Not set</span>;
  }
  const passed = isDatePassed(date);
  return (
    <span className={`${passed ? 'text-rose-600 font-bold' : ''}`}>
      {label}{formatDate(date)}
    </span>
  );
};

/**
 * API Service for Warehouse Inward Manager
 */

export interface ApiResponse<T> {
  data?: T;
  error?: string;
  details?: string;
}

export class ApiService {
  private static getHeaders(tokens: any) {
    const headers: any = {
      'Content-Type': 'application/json',
    };
    if (tokens) {
      try {
        headers['Authorization'] = `Bearer ${JSON.stringify(tokens)}`;
      } catch (err) {
        console.error('Failed to stringify tokens for Authorization header:', err);
      }
    }
    return headers;
  }

  static async checkAuth(tokens: any): Promise<ApiResponse<any>> {
    try {
      const response = await fetch('/api/auth/me', {
        headers: this.getHeaders(tokens)
      });
      const data = await response.json();
      if (response.ok) {
        return { data };
      }
      return { error: data.error || 'Auth check failed' };
    } catch (err: any) {
      return { error: err.message };
    }
  }

  static async getAuthUrl(): Promise<ApiResponse<{ url: string }>> {
    try {
      const response = await fetch('/api/auth/url');
      const data = await response.json();
      return { data };
    } catch (err: any) {
      return { error: err.message };
    }
  }

  static async logout(tokens: any): Promise<ApiResponse<{ success: boolean }>> {
    try {
      const response = await fetch('/api/auth/logout', {
        method: 'POST',
        headers: this.getHeaders(tokens)
      });
      const data = await response.json();
      return { data };
    } catch (err: any) {
      return { error: err.message };
    }
  }

  static async getSheetData(range: string, tokens: any): Promise<ApiResponse<any[][]>> {
    try {
      const response = await fetch(`/api/sheets/data?range=${encodeURIComponent(range)}`, {
        headers: this.getHeaders(tokens)
      });
      
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        return { error: 'Server returned non-JSON response. The connection might be warming up. Please try again in a moment.' };
      }

      const data = await response.json();
      if (response.ok) {
        return { data };
      }
      return { error: data.error, details: data.details };
    } catch (err: any) {
      return { error: err.message };
    }
  }

  static async batchGetSheetData(ranges: string[], tokens: any): Promise<ApiResponse<Record<string, any[][]>>> {
    try {
      const response = await fetch(`/api/sheets/batchGet?ranges=${encodeURIComponent(ranges.join(','))}`, {
        headers: this.getHeaders(tokens)
      });

      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        return { error: 'Connection busy. Please refresh the page or try again.' };
      }

      const data = await response.json();
      if (response.ok) {
        return { data };
      }
      return { error: data.error };
    } catch (err: any) {
      return { error: err.message };
    }
  }

  static async appendSheetData(range: string, values: any[][], tokens: any): Promise<ApiResponse<{ success: boolean }>> {
    try {
      const response = await fetch('/api/sheets/append', {
        method: 'POST',
        headers: this.getHeaders(tokens),
        body: JSON.stringify({ range, values })
      });

      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        return { error: 'Temporary connection issue. Please wait a second and click Confirm again.' };
      }

      const data = await response.json();
      if (response.ok) {
        return { data };
      }
      return { error: data.error };
    } catch (err: any) {
      return { error: err.message };
    }
  }

  static async updateSheetData(range: string, values: any[][], tokens: any): Promise<ApiResponse<{ success: boolean }>> {
    try {
      const response = await fetch('/api/sheets/update', {
        method: 'PUT',
        headers: this.getHeaders(tokens),
        body: JSON.stringify({ range, values })
      });

      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        return { error: 'Connection issue while updating master data. Please try again.' };
      }

      const data = await response.json();
      if (response.ok) {
        return { data };
      }
      return { error: data.error };
    } catch (err: any) {
      return { error: err.message };
    }
  }

  static async batchUpdateSheetData(data: { range: string, values: any[][] }[], tokens: any): Promise<ApiResponse<{ success: boolean }>> {
    try {
      const response = await fetch('/api/sheets/batchUpdate', {
        method: 'POST',
        headers: this.getHeaders(tokens),
        body: JSON.stringify({ data })
      });

      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        return { error: 'Connection issue during batch update. Please try again.' };
      }

      const responseData = await response.json();
      if (response.ok) {
        return { data: responseData };
      }
      return { error: responseData.error };
    } catch (err: any) {
      return { error: err.message };
    }
  }
}

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { CONFIG, FeatureFlags } from '../config';

interface FeatureContextType {
  features: FeatureFlags;
  toggleFeature: (id: keyof FeatureFlags) => void;
  getFeature: (id: keyof FeatureFlags) => boolean;
}

const FeatureContext = createContext<FeatureContextType | undefined>(undefined);

/**
 * FeatureProvider - Manages feature flags reactively
 */
export const FeatureProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [sessionOverrides, setSessionOverrides] = useState<Record<string, boolean>>({});

  // Initialize overrides from localStorage on mount
  useEffect(() => {
    const initialOverrides: Record<string, boolean> = {};
    CONFIG.inventory.forEach(f => {
      const val = localStorage.getItem(`FEATURE_OVERRIDE_${f.id}`);
      if (val !== null) initialOverrides[f.id] = val === 'true';
    });
    setSessionOverrides(initialOverrides);
  }, []);

  const getFeature = (id: keyof FeatureFlags): boolean => {
    // If we have a session override, use it (Development only)
    if (CONFIG.isDev && sessionOverrides[id] !== undefined) {
      return sessionOverrides[id];
    }
    // Fallback to the hardcoded config
    return CONFIG.features[id];
  };

  const toggleFeature = (id: keyof FeatureFlags) => {
    const currentVal = getFeature(id);
    const newVal = !currentVal;
    
    // Persist to localStorage
    localStorage.setItem(`FEATURE_OVERRIDE_${id}`, String(newVal));
    
    // Update state to trigger reactivity across the app
    setSessionOverrides(prev => ({ ...prev, [id]: newVal }));
  };

  // Construct current combined feature set
  const currentFeatures = { ...CONFIG.features };
  if (CONFIG.isDev) {
    Object.keys(sessionOverrides).forEach((key) => {
      currentFeatures[key as keyof FeatureFlags] = sessionOverrides[key];
    });
  }

  return (
    <FeatureContext.Provider value={{ features: currentFeatures, toggleFeature, getFeature }}>
      {children}
    </FeatureContext.Provider>
  );
};

export const useFeatures = () => {
  const context = useContext(FeatureContext);
  if (context === undefined) {
    throw new Error('useFeatures must be used within a FeatureProvider');
  }
  return context;
};

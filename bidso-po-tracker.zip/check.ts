import * as Lucide from 'lucide-react';

const icons = [
  'LayoutDashboard', 'PlusCircle', 'Search', 'Filter', 'ArrowRight', 
  'CheckCircle2', 'AlertCircle', 'Package', 'Factory', 'FileText',
  'Calendar', 'User', 'ChevronRight', 'Database', 'ArrowLeft',
  'IndianRupee', 'MessageSquare', 'Truck', 'Tag', 'Weight', 'List',
  'RefreshCw', 'Info', 'Clock', 'BarChart3', 'LogOut', 'Lock',
  'ShieldAlert', 'ShieldCheck', 'Loader2', 'Cloud', 'CloudOff',
  'Trash2', 'ChevronDown'
];

icons.forEach(name => {
  if (!Lucide[name]) {
    console.error(`MISSING ICON: ${name}`);
  }
});
console.log('Done checking icons');

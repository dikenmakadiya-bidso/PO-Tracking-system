import * as Lucide from 'lucide-react';
console.log('AlertTriangle exists?', !!Lucide.AlertTriangle);

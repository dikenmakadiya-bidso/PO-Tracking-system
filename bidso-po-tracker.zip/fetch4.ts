const url = "http://localhost:3000/node_modules/.vite/deps/motion_react.js";
fetch(url)
  .then(r => console.log(r.status))
  .catch(e => console.error(e));

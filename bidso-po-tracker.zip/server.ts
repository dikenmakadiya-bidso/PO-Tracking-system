import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { google } from 'googleapis';
import cookieSession from 'cookie-session';
import dotenv from 'dotenv';

dotenv.config();

// Extend Express Request type to include session
declare global {
  namespace Express {
    interface Request {
      session: {
        tokens?: any;
        user?: any;
      };
    }
  }
}

const __dirname = path.dirname(fileURLToPath(import.meta.url));

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Trust proxy for secure cookies in iframes
  app.set('trust proxy', 1);

  // Cookie Session Configuration
  app.use(cookieSession({
    name: 'session',
    keys: [process.env.SESSION_SECRET || 'warehouse-secret-key'],
    maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
    secure: true,
    sameSite: 'none',
    httpOnly: true,
  }));

  app.use(express.json());

  // Constants for security
  const ALLOWED_RANGES = [
    'Historical PO Data!A:Z',
    'Inward_Logs!A:Z'
  ];

  const ALLOWED_BATCH_RANGES = [
    'Historical PO Data!A:Z',
    'Inward_Logs!A:Z'
  ];

  // Sanitize APP_URL (remove trailing slash if present)
  const rawAppUrl = process.env.APP_URL || '';
  const sanitizedAppUrl = rawAppUrl.endsWith('/') ? rawAppUrl.slice(0, -1) : rawAppUrl;

  const oauth2Client = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    `${sanitizedAppUrl}/auth/callback`
  );

  // --- Auth Routes ---

  // Helper to get tokens from session or header
  const getTokens = (req: any) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      try {
        const tokens = JSON.parse(authHeader.substring(7));
        if (tokens) return tokens;
      } catch (e) {
        console.error('Failed to parse tokens from header');
      }
    }
    if (req.session?.tokens) return req.session.tokens;
    return null;
  };

  // Helper to create a fully configured auth client
  const getAuthClient = (req: any, tokens: any) => {
    const client = new google.auth.OAuth2(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET,
      `${sanitizedAppUrl}/auth/callback`
    );
    client.setCredentials(tokens);

    // Listen for token refreshes and update session
    client.on('tokens', (newTokens) => {
      if (req.session) {
        req.session.tokens = { ...tokens, ...newTokens };
      }
    });

    return client;
  };

  app.get('/api/auth/url', (req, res) => {
    const authOptions: any = {
      access_type: 'offline',
      prompt: 'consent select_account', // Force consent to ensure refresh token is provided
      scope: [
        'https://www.googleapis.com/auth/userinfo.email',
        'https://www.googleapis.com/auth/userinfo.profile',
        'https://www.googleapis.com/auth/spreadsheets',
        'https://www.googleapis.com/auth/drive.metadata.readonly'
      ],
    };

    // If a hosted domain is configured, add it to the auth URL
    if (process.env.GOOGLE_HD_DOMAIN) {
      authOptions.hd = process.env.GOOGLE_HD_DOMAIN;
    }

    const url = oauth2Client.generateAuthUrl(authOptions);
    res.json({ url });
  });

  app.get(['/auth/callback', '/auth/callback/'], async (req, res) => {
    const { code } = req.query;
    try {
      const { tokens } = await oauth2Client.getToken(code as string);
      
      // Merge tokens to avoid losing the refresh token
      const existingTokens = req.session?.tokens || {};
      const mergedTokens = { ...existingTokens, ...tokens };
      req.session!.tokens = mergedTokens;
      
      // Get user info
      oauth2Client.setCredentials(mergedTokens);
      const oauth2 = google.oauth2({ version: 'v2', auth: oauth2Client });
      const { data: userInfo } = await oauth2.userinfo.get();
      req.session!.user = userInfo;

      res.send(`
        <html>
          <head>
            <title>Authentication Successful</title>
            <style>
              body { font-family: sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; margin: 0; background: #f8fafc; color: #1e293b; }
              .card { background: white; padding: 2rem; rounded: 1rem; box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1); text-align: center; max-width: 400px; }
              .btn { background: #4f46e5; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 0.5rem; font-weight: bold; cursor: pointer; margin-top: 1rem; }
              .loader { border: 3px solid #f3f3f3; border-top: 3px solid #4f46e5; border-radius: 50%; width: 24px; height: 24px; animation: spin 1s linear infinite; margin: 0 auto 1rem; }
              @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
            </style>
          </head>
          <body>
            <div class="card">
              <div class="loader"></div>
              <h2>Login Successful!</h2>
              <p>We're redirecting you back to the Warehouse Portal.</p>
              <button class="btn" onclick="finish()">Close and Refresh App</button>
            </div>
            <script>
              function finish() {
                if (window.opener) {
                  window.opener.postMessage({ 
                    type: 'OAUTH_AUTH_SUCCESS',
                    tokens: ${JSON.stringify(mergedTokens)},
                    user: ${JSON.stringify(userInfo)}
                  }, '${sanitizedAppUrl}');
                  window.close();
                } else {
                  window.location.href = '/';
                }
              }
              // Auto-finish after 1 second
              setTimeout(finish, 1000);
            </script>
          </body>
        </html>
      `);
    } catch (error) {
      console.error('Auth error:', error);
      res.status(500).send('Authentication failed');
    }
  });

  app.get('/api/auth/me', async (req, res) => {
    const tokens = getTokens(req);
    if (!tokens) {
      return res.status(401).json({ error: 'Not authenticated' });
    }
    
    try {
      let user = req.session?.user || null;
      const auth = getAuthClient(req, tokens);

      // If user is not in session but we have tokens, fetch it
      if (!user) {
        try {
          const oauth2 = google.oauth2({ version: 'v2', auth });
          const { data: userInfo } = await oauth2.userinfo.get();
          user = userInfo;
          if (req.session) req.session.user = userInfo;
        } catch (e) {
          console.error('Failed to fetch user info with tokens:', e);
        }
      }
      
      // Check sheet permissions
      const drive = google.drive({ version: 'v3', auth });
      
      // Sanitize Sheet ID (remove full URL if user pasted it by mistake)
      let sheetId = process.env.GOOGLE_SHEET_ID || '';
      if (sheetId.includes('/d/')) {
        sheetId = sheetId.split('/d/')[1].split('/')[0];
      }
      
      if (!sheetId) {
        return res.json({ user, hasPermission: false, error: 'Sheet ID not configured' });
      }

      try {
        const { data: file } = await drive.files.get({
          fileId: sheetId,
          fields: 'capabilities'
        });
        
        const canEdit = file.capabilities?.canEdit || false;
        res.json({ user, hasPermission: canEdit });
      } catch (err: any) {
        console.error('Permission check error:', err.message);
        res.json({ user, hasPermission: false, error: 'No access to sheet. Check if Sheet ID is correct and you have access.' });
      }
    } catch (error) {
      res.status(401).json({ error: 'Session expired' });
    }
  });

  app.post('/api/auth/logout', (req, res) => {
    req.session = null;
    res.json({ success: true });
  });

  // --- Sheets API Proxy ---

  app.get('/api/sheets/data', async (req, res) => {
    const tokens = getTokens(req);
    if (!tokens) return res.status(401).json({ error: 'Unauthorized: Missing tokens' });
    
    const auth = getAuthClient(req, tokens);
    const sheets = google.sheets({ version: 'v4', auth });
    
    // Sanitize Sheet ID (remove full URL if user pasted it by mistake)
    let sheetId = process.env.GOOGLE_SHEET_ID || '';
    if (sheetId.includes('/d/')) {
      sheetId = sheetId.split('/d/')[1].split('/')[0];
    }
    
    const range = req.query.range as string || 'Historical PO Data!A:Z';

    if (!ALLOWED_RANGES.includes(range)) {
      return res.status(403).json({ error: 'Forbidden range' });
    }

    try {
      const response = await sheets.spreadsheets.values.get({
        spreadsheetId: sheetId,
        range,
      });
      
      if (!response.data.values || response.data.values.length === 0) {
        // If empty, let's see what sheets are available to help the user
        const spreadsheet = await sheets.spreadsheets.get({
          spreadsheetId: sheetId,
        });
        const sheetNames = spreadsheet.data.sheets?.map(s => s.properties?.title).filter(Boolean) || [];
        
        return res.status(404).json({ 
          error: `No data found in range "${range}".`,
          details: `The tab might be empty or missing. Available tabs in this spreadsheet: ${sheetNames.join(', ')}`
        });
      }
      
      res.json(response.data.values);
    } catch (error: any) {
      console.error(`Sheets API Error (${range}):`, error.message);
      
      let details = "Access denied or internal error.";
      if (error.code === 404) {
        details = "Spreadsheet ID not found. Check your GOOGLE_SHEET_ID secret.";
      } else if (error.message.includes('parse')) {
        // Likely a range error (tab name doesn't exist)
        try {
          const spreadsheet = await sheets.spreadsheets.get({
            spreadsheetId: sheetId,
          });
          const sheetNames = spreadsheet.data.sheets?.map(s => s.properties?.title).filter(Boolean) || [];
          details = `Tab not found. Available tabs: ${sheetNames.join(', ')}`;
        } catch (e) {
          details = "Tab not found and could not list available tabs.";
        }
      }

      res.status(error.code || 500).json({ 
        error: error.message,
        details
      });
    }
  });

  app.post('/api/sheets/append', async (req, res) => {
    const tokens = getTokens(req);
    if (!tokens) return res.status(401).json({ error: 'Unauthorized: Missing tokens' });
    
    const auth = getAuthClient(req, tokens);
    const sheets = google.sheets({ version: 'v4', auth });
    const sheetId = process.env.GOOGLE_SHEET_ID;
    const { range, values } = req.body;

    const isAllowed = ALLOWED_RANGES.some(allowed => 
      range === allowed || range.startsWith(allowed.split('!')[0] + '!')
    );

    if (!isAllowed) {
      return res.status(403).json({ error: 'Forbidden range' });
    }

    try {
      await sheets.spreadsheets.values.append({
        spreadsheetId: sheetId,
        range,
        valueInputOption: 'USER_ENTERED',
        insertDataOption: 'INSERT_ROWS',
        requestBody: { values },
      });
      res.json({ success: true });
    } catch (error: any) {
      res.status(error.code || 500).json({ error: error.message });
    }
  });

  app.put('/api/sheets/update', async (req, res) => {
    const tokens = getTokens(req);
    if (!tokens) return res.status(401).json({ error: 'Unauthorized: Missing tokens' });
    
    const auth = getAuthClient(req, tokens);
    const sheets = google.sheets({ version: 'v4', auth });
    const sheetId = process.env.GOOGLE_SHEET_ID;
    const { range, values } = req.body;

    const isAllowed = ALLOWED_RANGES.some(allowed => 
      range === allowed || range.startsWith(allowed.split('!')[0] + '!')
    );

    if (!isAllowed) {
      return res.status(403).json({ error: 'Forbidden range' });
    }

    try {
      await sheets.spreadsheets.values.update({
        spreadsheetId: sheetId,
        range,
        valueInputOption: 'USER_ENTERED',
        requestBody: { values },
      });
      res.json({ success: true });
    } catch (error: any) {
      res.status(error.code || 500).json({ error: error.message });
    }
  });

  app.post('/api/sheets/batchUpdate', async (req, res) => {
    const tokens = getTokens(req);
    if (!tokens) return res.status(401).json({ error: 'Unauthorized: Missing tokens' });
    
    const auth = getAuthClient(req, tokens);
    const sheets = google.sheets({ version: 'v4', auth });
    const sheetId = process.env.GOOGLE_SHEET_ID;
    const { data } = req.body; // Array of { range, values }

    if (!Array.isArray(data)) {
      return res.status(400).json({ error: 'Data must be an array' });
    }

    // Validate all ranges
    for (const d of data) {
      const isAllowed = ALLOWED_RANGES.some(allowed => 
        d.range === allowed || d.range.startsWith(allowed.split('!')[0] + '!')
      );
      if (!isAllowed) {
        return res.status(403).json({ error: `Forbidden range: ${d.range}` });
      }
    }

    try {
      await sheets.spreadsheets.values.batchUpdate({
        spreadsheetId: sheetId,
        requestBody: {
          valueInputOption: 'USER_ENTERED',
          data: data.map((d: any) => ({
            range: d.range,
            values: d.values
          }))
        }
      });
      res.json({ success: true });
    } catch (error: any) {
      console.error('Batch Update Error:', error.message);
      res.status(error.code || 500).json({ error: error.message });
    }
  });

  app.get('/api/sheets/batchGet', async (req, res) => {
    const tokens = getTokens(req);
    if (!tokens) return res.status(401).json({ error: 'Unauthorized: Missing tokens' });
    
    const auth = getAuthClient(req, tokens);
    const sheets = google.sheets({ version: 'v4', auth });
    const sheetId = process.env.GOOGLE_SHEET_ID;
    const ranges = (req.query.ranges as string || '').split(',');

    // Validate all ranges
    for (const range of ranges) {
      if (!ALLOWED_BATCH_RANGES.includes(range)) {
        return res.status(403).json({ error: `Forbidden range: ${range}` });
      }
    }

    try {
      const response = await sheets.spreadsheets.values.batchGet({
        spreadsheetId: sheetId,
        ranges,
      });
      
      const result: Record<string, any[][]> = {};
      response.data.valueRanges?.forEach(vr => {
        if (vr.range && vr.values) {
          // The range returned by Google might be slightly different (e.g. 'Sheet1!A1:Z100')
          // We try to match it back to the requested range
          const requestedRange = ranges.find(r => vr.range?.includes(r.split('!')[0]));
          result[requestedRange || vr.range] = vr.values;
        }
      });
      
      res.json(result);
    } catch (error: any) {
      console.error('Batch Get Error:', error.message);
      res.status(error.code || 500).json({ error: error.message });
    }
  });

  // --- Vite / Static Serving ---

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();

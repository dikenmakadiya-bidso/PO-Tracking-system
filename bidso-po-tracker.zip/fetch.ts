const url = "http://localhost:3000/";
fetch(url)
  .then(r => r.text())
  .then(html => console.log(html.substring(0, 500)))
  .catch(e => console.error(e));

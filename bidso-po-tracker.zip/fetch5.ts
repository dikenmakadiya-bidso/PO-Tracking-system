const url = "http://localhost:3000/src/index.css";
fetch(url)
  .then(r => r.text())
  .then(text => console.log(text.substring(0, 500)))
  .catch(e => console.error(e));

const url = "http://localhost:3000/src/main.tsx";
fetch(url)
  .then(r => {
    console.log(r.status);
    return r.text();
  })
  .then(html => console.log(html.substring(0, 500)))
  .catch(e => console.error(e));

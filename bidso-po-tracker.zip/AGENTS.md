# Agent Instructions

## Persistent Rules
- **Strict Adherence**: Follow only the instructions given in the current message. Ignore all previous instructions, even if they were not explicitly cancelled.
- **No Assumptions**: Do not assume, infer, or add any extra tasks or improvements beyond what is explicitly asked.
- **Clarification First**: If something is unclear, ask for clarification instead of making assumptions.
- **Documentation First**: Whenever you add a new feature that requires additional setup (new env vars, new sheet tabs, new Google Cloud scopes, etc.), you MUST update `SETUP_GUIDE.md` immediately to reflect these changes.
- **Error Handling**: Always use the "Strict Validation & Handshake" approach for API calls to prevent "Unexpected token <" errors caused by connection warm-ups or redirects.
- **Proactive Suggestions**: You are encouraged to pitch new ideas or improvements based on the project's evolution, though execution must always await explicit approval.
- **Documentation Sync**: Whenever you modify or add core business logic, you MUST update `LOGIC_DOCUMENTATION.md` to reflect these changes in plain English for the user.
- **Feature Pipeline Management**: Whenever the user describes a new feature or significant enhancement, you MUST ask if they would like to add it to the `FEATURE_INVENTORY` in `src/config.ts` before starting the implementation. This ensures all work-in-progress is behind a feature flag.

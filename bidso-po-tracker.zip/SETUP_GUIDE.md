# 🚀 Complete Setup & Deployment Manual (Zero-to-One)

This guide provides a comprehensive, step-by-step walkthrough to set up the **Warehouse Inward Manager** from scratch. 

---

## 🛠 Step 1: Google Cloud Project Configuration
Everything starts in the [Google Cloud Console](https://console.cloud.google.com/).

1.  **Create Project**: 
    - Click the project dropdown (top-left) > **New Project**.
    - Name it (e.g., `bidso-warehouse-manager`).
2.  **Enable APIs**:
    - Go to **APIs & Services > Library**.
    - Search for and **Enable** these two APIs:
        *   `Google Sheets API`
        *   `Google Drive API`
3.  **Configure OAuth Consent Screen**:
    - Go to **APIs & Services > OAuth consent screen**.
    - Select **Internal** (if using a Google Workspace/Business account) or **External**.
    - **Step 1 (App info)**: Provide App name and user support email.
    - **Step 2 (Scopes)**: This is CRITICAL. Click **Add or Remove Scopes** and manually add:
        *   `.../auth/spreadsheets` (Read/Write access to Sheets)
        *   `.../auth/userinfo.email` (To identify which staff is logged in)
        *   `.../auth/userinfo.profile`
    - **Step 3 (Test users)**: If "External", add the developer's email here.
4.  **Create Credentials**:
    - Go to **APIs & Services > Credentials**.
    - Click **+ Create Credentials** > **OAuth client ID**.
    - Select **Web application**.
    - **Authorized Redirect URIs**: 
        *   Production: `https://your-app-domain.run.app/auth/callback`
        *   Development: `http://localhost:3000/auth/callback`
    - Click **Create**. Copy the **Client ID** and **Client Secret**.

---

## 📊 Step 2: Preparing the Master Spreadsheet
The app requires one Google Sheet with two specific tabs.

1.  **Create a New Spreadsheet**: Name it `Warehouse Master Sheet`.
2.  **Get the ID**: Copy the long string in the URL between `/d/` and `/edit`.
    *   Example: `https://docs.google.com/spreadsheets/d/1A2B3C4D5E6F/edit` -> ID is `1A2B3C4D5E6F`.
3.  **Tab 1: `Historical PO Data`**:
    *   This is your "Database". Create headers exactly:
    *   `Unique ID` | `Plant Name` | `Bidso PO no` | `RM Code` | `RM Name` | `Vendor` | `Order Quantity` | `Received QTY` | `Inv UOM` | `Conversion Factor (PCs/KG)`
4.  **Tab 2: `Inward_Logs`**:
    *   This is for transaction records. Create headers:
    *   `Entry Date` | `Bidso PO No` | `RM Code` | `RM Name` | `New Received Quantity` | `Entry Note` | `Plant Name` | `Time stamp` | `Unique ID` | `User ID` | `User Email` | `Transaction ID` | `Inv UOM` | `Conversion Factor`
5.  **User Permissions**: Share the sheet with **Full Edit Access** to the emails/groups that will use the app.

---

## 💻 Step 3: Environment Configuration
Create a `.env` file in the root folder. **Never commit this file to Git.**

```env
# 1. AUTHENTICATION
SESSION_SECRET=a_very_long_random_string_here
GOOGLE_CLIENT_ID=copied_from_cloud_console
GOOGLE_CLIENT_SECRET=copied_from_cloud_console

# 2. APPLICATION URL
# IMPORTANT: Must match the redirect URI in Google Cloud
APP_URL=http://localhost:3000

# 3. DATA SOURCE
GOOGLE_SHEET_ID=copied_from_sheet_url

# 4. OPTIONAL SECURITY
# Limits login only to your company email
GOOGLE_HD_DOMAIN=bidso.com
```

---

## 🏃 Step 4: Running for Developers

1.  **Dependencies**: Run `npm install`.
2.  **Database Handshake**: The app uses `firebase` for minor config or state (optional), but the primary DB is Sheets. Ensure `GOOGLE_SHEET_ID` is correct.
3.  **Start App**: Run `npm run dev`.
4.  **The First Login**: 
    - Open `localhost:3000`.
    - Click "Login with Google".
    - Accept the "Access to your Google Sheets/Drive" permissions checkbox (Standard Google Warning).

---

## 🔍 Troubleshooting & Implementation Details
- **Unexpected Token `<` (JSON Error)**: This often happens due to 'cold starts' in the API connection. We use a **Pre-warm Handshake** in `App.tsx` via a `useEffect` that checks auth as soon as the Inward tab is opened.
- **Error 401/403**: Check if user has "Editor" access to the Sheet.
- **Redirect URI Mismatch**: Ensure the `APP_URL` in `.env` exactly matches what you typed in the Google Cloud Console.
- **Port 3000**: AI Studio and many hosting providers expect port 3000. Do not change this in `server.ts` or `vite.config.ts`.

---

## 📝 Developer Guidelines
**Rule #1: Maintain this Guide.** Whenever a new feature is added that requires a new environment variable, a new sheet tab, or a change in the Google Cloud settings, this `SETUP_GUIDE.md` **MUST** be updated immediately.

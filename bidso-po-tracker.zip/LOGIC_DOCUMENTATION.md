# Complete Application Logic Documentation

This document provides a detailed breakdown of the business logic, calculations, and automated workflows implemented in the Purchase Order Management Application. It is designed to ensure full clarity for users and future developers.

---

## 1. Data Enrichment & "Live" Quantity Sync

The application does not simply display raw data from your Google Sheet. It performs a **Live Enrichment** every time the app loads or syncs.

### A. How `Received QTY` is Calculated
In your "Historical PO Data" sheet, you might have a column for quantity already received. However, the app also has an "Inward Logs" sheet for new receipts.
*   **The Logic**: For every single Purchase Order, the app calculates a `logsSum` by adding up every entry in the "Inward Logs" that matches that PO.
*   **The Rule**: The App displays the `Final Received QTY` as the **higher** of two values:
    1.  The value currently written in the "Historical PO Data" sheet.
    2.  The sum of all matching logs in "Inward Logs".
*   **Purpose**: This ensures that even if you haven't manually updated your main sheet yet, the app shows the most up-to-date "live" status based on fresh inward logs.

### B. Intelligent Row Matching
To link logs to POs accurately, the app uses a **Hierarchical Matching Algorithm**:
1.  **Tier 1 (Unique ID)**: If a "Unique ID" header is found, it uses this first. This is a 100% accurate match.
2.  **Tier 2 (Composite Key)**: If no Unique ID is reliable, it matches using `Bidso PO Number` AND `RM Code`. 
*   **Why?**: A single PO might have 5 different materials. By matching both the PO number and the Material Code, we ensure that the delivery of "Steel" isn't accidentally credited to the order for "Copper".

---

## 2. Order Status Engine

The status of an order (`Pending`, `Partial`, or `Completed`) is **calculated in real-time** by the code, not read from the sheet. This ensures the dashboard charts always reflect the "live" reality.

*   **COMPLETED**: Triggered when `Received QTY` is equal to or greater than `Order Quantity`.
    *   *Note*: We use "greater than or equal to" to handle "over-deliveries" gracefully.
*   **PARTIAL**: Triggered when `Received QTY` is greater than `0` but still less than the `Order Quantity`.
*   **PENDING**: Triggered when `Received QTY` is exactly `0`.

---

## 3. Lead Time & Automated ETA

The application includes an intelligence layer that automatically manages delivery dates.

### A. Historical Lead Time Calculation
The app scans every historical order that has been **Completed** or **Partially Received**.
1.  It finds the `PO Issuance Date`.
2.  It looks for the **earliest** dated entry in the "Inward Logs" for that material.
3.  `Lead Time = Earliest Receipt Date - Issuance Date`.

### B. Predictive Precision Hierarchy
The app determines the most likely arrival date using two levels of logic:
1.  **Level 1 (Vendor-Specific)**: The app calculates the average lead time for that *specific Material* from that *specific Vendor*. (e.g., "A-1 Supplies" usually takes 7 days for "Steel"). 
2.  **Level 2 (Material Average)**: A fallback average for that material across *all other vendors* in your history.

### C. Automated Data Integration
Instead of showing a secondary prediction in the app, this logic is used to **automatically fill the "Expected delivery date"** in your Google Sheet (see Logic #5). This ensures your source data is always complete and accurate without manual entry.

---

## 4. Smart Input Automation (The "Memory" Feature)

### A. Material Memory
When you go to the **"Inward"** tab to record a new delivery:
1.  You select a material (**RM Code**).
2.  **The Logic**: The app immediately scans your entire history to find the most recent PO for that specific material.
3.  **The Result**: It automatically fills in the **Conversion Factor** if it finds a match. For **INV UOM**, it will prompt you to select the unit to ensure 100% accuracy, though it will remember your preference from previous orders.
*   **Purpose**: This eliminates repetitive typing and prevents "Human Error" (e.g., accidentally typing 'Kgs' instead of 'MT').

### B. Real-Time Quantity Validation
While entering a new inward receipt:
*   **Validation**: The app constantly compares the `New Received Quantity` you type against the remaining `Balance` for that PO.
*   **Feedback**: 
    - The input field turns **Red** and shows an **"Exceeds Balance"** warning if you type a quantity higher than what is pending.
    - It shows a live **"Remaining Balance"** calculation below the input.
    - The input turns **Green** if your entry exactly completes the order.
*   **Labeling**: The quantity field label is dynamic; it displays **"New Received Quantity (in {Selected_UOM})"** (e.g., in KG or in PCs) once a unit is selected, ensuring precision during entry.
*   **Purpose**: This provides an immediate safety net to prevent accidental over-entry before you hit submit.

## 5. Inward Receipt History (Audit Trail)

The application now maintains a detailed audit trail for every Purchase Order:
*   **Access**: Clicking any PO card in the **History** tab opens the **Purchase Order Insight** modal.
*   **Details**: This modal lists every historical inward receipt for that PO, including:
    - **Entry Date**: When the material was received.
    - **Quantity**: Exactly how much was added in that specific transaction.
    - **User ID**: The identity of the person who recorded the entry.
*   **Consolidation**: The trail automatically merges logs from the Google Sheet with your recent **Pending Sync** local logs to show a truly "Real-Time" status.

---

## 6. Sync-time Automation (Sheet Cleanup)

Every time you click **"Sync"**, the app runs a "background doctor" on your Google Sheet.

### The Problem
Sometimes users add rows to the Google Sheet manually and forget to fill in the "Expected delivery date". This makes the Analysis dashboard inaccurate.

### The Automated Solution
1.  **Identify**: The app finds all rows where the "Expected delivery date" is blank.
2.  **Predict**: It uses the Lead Time Engine (Logic #3) to calculate the most likely arrival date.
3.  **Repair**: It writes these predicted dates **directly back into your Google Sheet**.
4.  **Batch Technology**: Instead of sending 100 separate updates (which makes the app slow), it sends **one single "Batch Update"**. This is high-speed and prevents the Google API from hitting "Rate Limits" (crashing).

---

## 6. Analysis & Dashboard Logic

### A. Monthly Intelligence
All charts are grouped by the month the PO was **issued**, not when it was received. This helps you understand your buying patterns.

### B. Delay Detection
An order is classified as "Delayed" in the analysis if:
1.  Its status is NOT "Completed".
2.  The current date is **past** the "Expected delivery date".
*   *Note*: The app updates this classification every time you open it, ensuring you see today's delays instantly.

### C. Plant-Level Siloing
The app identifies which "Plant" you belong to. Even if your Google Sheet contains data for 20 different factories, the app filters everything so you only see, search, and analyze data for your specific location.

---

## 7. Global Search & Fuzzy Matching

The search bar at the top of the History tab is a "Full-Text Search" engine.
*   **Columns Scanned**: Unique ID, RM Name, RM Code, Vendor Name.
*   **Behavior**: It uses "Fuzzy Matching," meaning if you type "Steel", it will find "Stainless Steel Pipe" and "Reinforcement Steel". It is not case-sensitive.

---

## 8. Offline Mode & Background Synchronization

To facilitate seamless operation in warehouse environments with unstable internet access, the application incorporates a robust offline mode framework.

### A. Offline Storage & Caching
*   **Core Assets Cache**: The active Purchase Orders, historical Logs, headers, and the primary identity keys are saved directly into the browser's `localStorage` every time a successful sync is made. This ensures that if the internet connection is lost, users can still fully access their history, search POs, and verify records.
*   **Material Master Memory**: Features such as Material UOM memory and PCs/KG conversion factors are completely functional offline, pulling data from local copies of the PO database.

### B. Queue-Based Offline Transactions
When a user records a material inward entry or updates master details while offline:
1.  **Immediate Local Feedback**: The transaction is saved locally and immediately reflects in the local logs tab with a prominent "Pending Sync" status.
2.  **Instant PO Updating**: The app's local memory of that PO is enriched instantly, reducing physical balances, updating statuses, and saving UOM/PCS/KG overrides in a background `pendingMasterUpdates` queue.
3.  **Automatic Return Syncing**: The browser continuously listens to network status updates. Once connection is restored (or when a manual "Sync Now" is pressed online), the background engine iterates over both queues sequentially, pushing entries to Google Sheets' log table and updating material master definitions safely without duplicate transactions or rate limit issues.

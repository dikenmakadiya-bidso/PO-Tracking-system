const url = "http://localhost:3000/src/App.tsx";
fetch(url)
  .then(r => {
    console.log(r.status);
    return r.text();
  })
  .then(html => {
    if (html.includes("Error")) console.log("ERROR IN RESPONSE");
    console.log(html.substring(0, 500))
  })
  .catch(e => console.error(e));
